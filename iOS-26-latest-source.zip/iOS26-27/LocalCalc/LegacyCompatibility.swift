import SwiftUI
#if LEGACY_APP
import UIKit
#endif

extension View {
    func appOnChange<Value: Equatable>(of value: Value, perform action: @escaping (Value) -> Void) -> some View {
        #if LEGACY_APP
        self.onChange(of: value, perform: action)
        #else
        self.onChange(of: value) { _, newValue in action(newValue) }
        #endif
    }

    @ViewBuilder
    func appGlassButtonStyle(prominent: Bool = false) -> some View {
        #if LEGACY_APP
        if prominent {
            self.buttonStyle(.borderedProminent)
        } else {
            self.buttonStyle(.bordered)
        }
        #else
        if prominent {
            self.buttonStyle(.glassProminent)
        } else {
            self.buttonStyle(.glass)
        }
        #endif
    }

    @ViewBuilder
    func appScrollDismissesKeyboard() -> some View {
        #if LEGACY_APP
        self
        #else
        self.scrollDismissesKeyboard(.interactively)
        #endif
    }

    @ViewBuilder
    func appScrollIndicatorsHidden() -> some View {
        #if LEGACY_APP
        self
        #else
        self.scrollIndicators(.hidden)
        #endif
    }

    @ViewBuilder
    func appSheetPresentation(compact: Bool = false) -> some View {
        #if LEGACY_APP
        self
        #else
        if compact {
            self.presentationDetents([.medium])
        } else {
            self.presentationDetents([.medium, .large]).presentationDragIndicator(.visible)
        }
        #endif
    }
}

struct AppNavigationContainer<Content: View>: View {
    @ViewBuilder var content: Content

    var body: some View {
        #if LEGACY_APP
        NavigationView { content }
        #else
        NavigationStack { content }
        #endif
    }
}

struct AppEmptyState: View {
    let title: String
    let symbol: String
    var message: String? = nil

    var body: some View {
        #if LEGACY_APP
        VStack(spacing: 10) {
            Image(systemName: symbol).font(.system(size: 32)).foregroundColor(.secondary)
            Text(title).font(.headline)
            if let message { Text(message).font(.footnote).foregroundColor(.secondary).multilineTextAlignment(.center) }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .padding(24)
        #else
        if let message {
            ContentUnavailableView(title, systemImage: symbol, description: Text(message))
        } else {
            ContentUnavailableView(title, systemImage: symbol)
        }
        #endif
    }
}

#if LEGACY_APP
typealias SensoryFeedback = AppHapticFeedback

enum LegacyHaptics {
    static func play(_ feedback: SensoryFeedback) {
        let configuredLevel = UserDefaults.standard.object(forKey: "haptics.intensity") as? Double ?? 0.7
        let level = min(1, configuredLevel * 1.25)
        switch feedback {
        case let .impact(weight, intensity):
            let style: UIImpactFeedbackGenerator.FeedbackStyle
            switch weight {
            case .light: style = .light
            case .medium: style = .medium
            case .heavy: style = .heavy
            }
            let generator = UIImpactFeedbackGenerator(style: style)
            generator.prepare()
            generator.impactOccurred(intensity: CGFloat(min(max(intensity * level * (weight == .light ? 1.35 : 1.2), 0), 1)))
        case .selection:
            let generator = UIImpactFeedbackGenerator(style: .light)
            generator.prepare()
            generator.impactOccurred(intensity: CGFloat(0.42 * level))
        case .start:
            let generator = UIImpactFeedbackGenerator(style: .medium)
            generator.prepare()
            generator.impactOccurred(intensity: CGFloat(0.72 * level))
        case .success:
            let generator = UIImpactFeedbackGenerator(style: .heavy)
            generator.prepare()
            generator.impactOccurred(intensity: CGFloat(0.92 * level))
        case .error:
            let generator = UIImpactFeedbackGenerator(style: .heavy)
            generator.prepare()
            generator.impactOccurred(intensity: CGFloat(level))
        }
    }
}

extension View {
    func sensoryFeedback<Value: Equatable>(trigger: Value, _ feedback: @escaping () -> SensoryFeedback?) -> some View {
        onChange(of: trigger) { _ in
            if let feedback = feedback() { LegacyHaptics.play(feedback) }
        }
    }

    func sensoryFeedback<Value: Equatable>(_ feedback: SensoryFeedback, trigger: Value, condition: @escaping (Value, Value) -> Bool) -> some View {
        onChange(of: trigger) { value in
            if condition(value, value) { LegacyHaptics.play(feedback) }
        }
    }
}
#endif
