import SwiftUI
import LocalAuthentication

@main
struct LocalCalcApp: App {
    var body: some Scene {
        WindowGroup {
            #if LEGACY_APP
            LegacyOSGate()
                .preferredColorScheme(.dark)
            #else
            MainView()
                .preferredColorScheme(.dark)
            #endif
        }
    }
}

enum AppTab: Int, CaseIterable {
    case calculator, converter, currency, history

    var title: String {
        switch self {
        case .calculator: "计算"
        case .converter: "换算"
        case .currency: "汇率"
        case .history: "历史"
        }
    }

    var symbol: String {
        switch self {
        case .calculator: "function"
        case .converter: "arrow.left.arrow.right"
        case .currency: "chart.line.uptrend.xyaxis"
        case .history: "clock.arrow.circlepath"
        }
    }
}

#if LEGACY_APP
private struct LegacyOSGate: View {
    var body: some View {
        if ProcessInfo.processInfo.operatingSystemVersion.majorVersion <= 18 {
            MainView()
        } else {
            VStack(spacing: 12) {
                Image(systemName: "iphone.slash").font(.system(size: 36)).foregroundColor(.cyan)
                Text("旧版系统专用").font(.title2.bold())
                Text("此版本适用于 iOS 15 至 iOS 18。请安装适用于当前系统的版本。")
                    .font(.body).foregroundColor(.secondary).multilineTextAlignment(.center)
            }
            .padding(28)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color(red: 0.035, green: 0.045, blue: 0.075).ignoresSafeArea())
        }
    }
}
#endif

enum KeyboardInput: Hashable {
    case converterAmount
    case currencyAmount
}

struct MainView: View {
    @Environment(\.scenePhase) private var scenePhase
    @State private var selected = AppTab.calculator
    @State private var isHistoryUnlocked = false
    @State private var isAuthenticatingHistory = false
    @State private var authenticationError: String?
    @FocusState private var keyboardFocus: KeyboardInput?
    @AppStorage("haptics.enabled") private var hapticsEnabled = true
    @StateObject private var historyStore = HistoryStore()

    var body: some View {
        ZStack {
            #if LEGACY_APP
            Color.black.ignoresSafeArea()
            #else
            Color(red: 0.035, green: 0.045, blue: 0.075).ignoresSafeArea()
            #endif
            tabContent
        }
            .tint(.cyan)
            .appOnChange(of: selected) { _ in keyboardFocus = nil }
            .appOnChange(of: scenePhase) { phase in
                if phase == .background, selected == .history {
                    isHistoryUnlocked = false
                } else if phase == .active, selected == .history, !isHistoryUnlocked {
                    authenticateForHistory()
                }
            }
            .alert("无法验证身份", isPresented: Binding(
                get: { authenticationError != nil },
                set: { if !$0 { authenticationError = nil } }
            )) {
                Button("好", role: .cancel) { authenticationError = nil }
            } message: {
                Text(authenticationError ?? "请稍后重试。")
            }
    }

    private var tabContent: some View {
        TabView(selection: Binding(get: { selected }, set: { selectTab($0) })) {
            swipeable(CalculatorView(historyStore: historyStore), tab: .calculator)
                .tabItem { Label("计算", systemImage: AppTab.calculator.symbol) }
                .tag(AppTab.calculator)
            swipeable(ConverterView(keyboardFocus: $keyboardFocus, historyStore: historyStore), tab: .converter)
                .tabItem { Label("换算", systemImage: AppTab.converter.symbol) }
                .tag(AppTab.converter)
            swipeable(CurrencyView(keyboardFocus: $keyboardFocus, historyStore: historyStore), tab: .currency)
                .tabItem { Label("汇率", systemImage: AppTab.currency.symbol) }
                .tag(AppTab.currency)
            swipeable(HistoryView(
                historyStore: historyStore,
                isUnlocked: isHistoryUnlocked,
                isAuthenticating: isAuthenticatingHistory,
                retryAuthentication: authenticateForHistory
            ), tab: .history)
                .tabItem { Label("历史", systemImage: AppTab.history.symbol) }
                .tag(AppTab.history)
        }
    }


    @ViewBuilder
    private func swipeable<Content: View>(_ content: Content, tab: AppTab) -> some View {
        if tab == .history {
            content.frame(maxWidth: .infinity, maxHeight: .infinity)
        } else {
            content
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .contentShape(Rectangle())
                .simultaneousGesture(DragGesture(minimumDistance: 32).onEnded { value in
                    guard abs(value.translation.width) > abs(value.translation.height) else { return }
                    let next = tab.rawValue + (value.translation.width < 0 ? 1 : -1)
                    guard let destination = AppTab(rawValue: min(max(next, 0), AppTab.allCases.count - 1)) else { return }
                    guard destination != selected else { return }
                    withAnimation(.easeOut(duration: 0.25)) { selectTab(destination) }
                })
        }
    }

    private func selectTab(_ tab: AppTab) {
        guard tab != selected, !isAuthenticatingHistory else { return }
        #if LEGACY_APP
        if hapticsEnabled { LegacyHaptics.play(.selection) }
        #else
        AppHapticPlayer.play(.selection, enabled: hapticsEnabled)
        #endif
        if tab == .history {
            authenticateForHistory()
        } else {
            if selected == .history { isHistoryUnlocked = false }
            selected = tab
        }
    }

    private func authenticateForHistory() {
        guard !isAuthenticatingHistory else { return }
        isAuthenticatingHistory = true
        isHistoryUnlocked = false
        selected = .history

        Task {
            await Task.yield()
            let context = LAContext()
            var policyError: NSError?
            guard context.canEvaluatePolicy(.deviceOwnerAuthentication, error: &policyError) else {
                authenticationError = policyError?.localizedDescription ?? "请先在系统设置中启用设备密码。"
                isAuthenticatingHistory = false
                return
            }

            do {
                try await context.evaluatePolicy(.deviceOwnerAuthentication, localizedReason: "验证身份以查看历史记录")
                isHistoryUnlocked = true
            } catch {
                if let laError = error as? LAError,
                   ![.userCancel, .systemCancel, .appCancel].contains(laError.code) {
                    authenticationError = error.localizedDescription
                }
            }
            isAuthenticatingHistory = false
        }
    }
}
