import Foundation

enum ExpressionEvaluator {
    private enum Token: Equatable {
        case number(Double), op(String), name(String), left, right, comma
    }

    static func evaluate(_ source: String, degrees: Bool) throws -> Double {
        var parser = try Parser(tokens: tokenize(source), degrees: degrees)
        let value = try parser.expression()
        guard parser.isAtEnd, value.isFinite else { throw CalcError.invalid }
        return value
    }

    private static func tokenize(_ source: String) throws -> [Token] {
        let chars = Array(source.replacingOccurrences(of: "×", with: "*").replacingOccurrences(of: "÷", with: "/").replacingOccurrences(of: "−", with: "-").replacingOccurrences(of: " ", with: ""))
        var out: [Token] = [], i = 0
        while i < chars.count {
            let c = chars[i]
            if c.isNumber || c == "." {
                let start = i; i += 1
                while i < chars.count && (chars[i].isNumber || chars[i] == ".") { i += 1 }
                if i < chars.count && (chars[i] == "e" || chars[i] == "E") {
                    var exponentEnd = i + 1
                    if exponentEnd < chars.count && (chars[exponentEnd] == "+" || chars[exponentEnd] == "-") { exponentEnd += 1 }
                    let digitsStart = exponentEnd
                    while exponentEnd < chars.count && chars[exponentEnd].isNumber { exponentEnd += 1 }
                    if exponentEnd > digitsStart { i = exponentEnd }
                }
                guard let value = Double(String(chars[start..<i])) else { throw CalcError.invalid }
                out.append(.number(value)); continue
            }
            if c.isLetter {
                let start = i; i += 1
                while i < chars.count && (chars[i].isLetter || chars[i].isNumber) { i += 1 }
                out.append(.name(String(chars[start..<i]).lowercased())); continue
            }
            switch c {
            case "(": out.append(.left)
            case ")": out.append(.right)
            case ",": out.append(.comma)
            case "+", "-", "*", "/", "^", "%", "!": out.append(.op(String(c)))
            default: throw CalcError.invalid
            }
            i += 1
        }
        return out
    }

    private enum CalcError: Error { case invalid }
    private struct Parser {
        let tokens: [Token]
        let degrees: Bool
        var index = 0
        var isAtEnd: Bool { index == tokens.count }
        init(tokens: [Token], degrees: Bool) { self.tokens = tokens; self.degrees = degrees }
        var current: Token? { index < tokens.count ? tokens[index] : nil }
        mutating func take() -> Token? { guard index < tokens.count else { return nil }; defer { index += 1 }; return tokens[index] }

        mutating func expression() throws -> Double { try addition() }
        mutating func addition() throws -> Double {
            var x = try multiplication()
            while let t = current, t == .op("+") || t == .op("-") {
                _ = take(); let y = try multiplication(); x = t == .op("+") ? x + y : x - y
            }
            return x
        }
        mutating func multiplication() throws -> Double {
            var x = try power()
            while let t = current, t == .op("*") || t == .op("/") {
                _ = take(); let y = try power()
                if t == .op("/") && y == 0 { throw CalcError.invalid }
                x = t == .op("*") ? x * y : x / y
            }
            return x
        }
        mutating func power() throws -> Double {
            var x = try unary()
            if current == .op("^") { _ = take(); x = Foundation.pow(x, try power()) }
            return x
        }
        mutating func unary() throws -> Double {
            if current == .op("-") { _ = take(); return -(try unary()) }
            if current == .op("+") { _ = take(); return try unary() }
            var x = try primary()
            while let t = current, t == .op("%") || t == .op("!") {
                _ = take()
                if t == .op("%") { x /= 100 }
                else {
                    guard x >= 0, x <= 170, x.rounded() == x else { throw CalcError.invalid }
                    let n = Int(x)
                    x = n < 2 ? 1 : (2...n).reduce(1.0) { $0 * Double($1) }
                }
            }
            return x
        }
        mutating func primary() throws -> Double {
            guard let t = take() else { throw CalcError.invalid }
            switch t {
            case .number(let x): return x
            case .left:
                let x = try expression(); guard take() == .right else { throw CalcError.invalid }; return x
            case .name(let name):
                if name == "pi" { return .pi }; if name == "e" { return M_E }
                guard take() == .left else { throw CalcError.invalid }
                let raw = try expression()
                if name == "root" {
                    guard take() == .comma else { throw CalcError.invalid }
                    let degree = try expression()
                    guard take() == .right, degree != 0 else { throw CalcError.invalid }
                    if raw < 0 {
                        guard degree.rounded() == degree, abs(degree.truncatingRemainder(dividingBy: 2)) == 1 else { throw CalcError.invalid }
                        return -Foundation.pow(-raw, 1 / degree)
                    }
                    return Foundation.pow(raw, 1 / degree)
                }
                guard take() == .right else { throw CalcError.invalid }
                let radians = degrees ? raw * .pi / 180 : raw
                switch name {
                case "sin": return sin(radians)
                case "cos": return cos(radians)
                case "tan": return tan(radians)
                case "asin": return (degrees ? 180 / .pi : 1) * asin(raw)
                case "acos": return (degrees ? 180 / .pi : 1) * acos(raw)
                case "atan": return (degrees ? 180 / .pi : 1) * atan(raw)
                case "sinh": return sinh(raw)
                case "cosh": return cosh(raw)
                case "tanh": return tanh(raw)
                case "asinh": return asinh(raw)
                case "acosh": return acosh(raw)
                case "atanh": return atanh(raw)
                case "sqrt": guard raw >= 0 else { throw CalcError.invalid }; return sqrt(raw)
                case "ln": guard raw > 0 else { throw CalcError.invalid }; return log(raw)
                case "log", "log10": guard raw > 0 else { throw CalcError.invalid }; return log10(raw)
                case "exp": return Foundation.exp(raw)
                default: throw CalcError.invalid
                }
            default: throw CalcError.invalid
            }
        }
    }
}
