import SwiftUI
import LocalAuthentication

struct HistoryView: View {
    @ObservedObject var historyStore: HistoryStore
    let isUnlocked: Bool
    let isAuthenticating: Bool
    let retryAuthentication: () -> Void
    @AppStorage("haptics.enabled") private var hapticsEnabled = true
    @State private var isClearConfirmationPresented = false
    @State private var biometryType: LABiometryType = .none

    private var lockedSymbol: String {
        switch biometryType {
        case .touchID: "touchid"
        case .faceID: "faceid"
        default: "lock.fill"
        }
    }

    private var lockedMessage: String {
        if isAuthenticating {
            switch biometryType {
            case .touchID: "请将手指放在主屏幕按钮上完成 Touch ID 验证。"
            case .faceID: "请看向 iPhone 完成 Face ID 验证。"
            default: "请完成设备身份验证。"
            }
        } else {
        switch biometryType {
        case .touchID: "请使用 Touch ID 或设备密码验证身份。"
        case .faceID: "请使用 Face ID 或设备密码验证身份。"
        default: "请使用设备密码验证身份。"
        }
        }
    }

    var body: some View {
        AppNavigationContainer {
            Group {
                if isUnlocked {
                    List {
                        ForEach(historyStore.records) { record in
                            HistoryRow(record: record)
                                .listRowBackground(Color.white.opacity(0.045))
                                .swipeActions(edge: .trailing, allowsFullSwipe: true) {
                                    Button(role: .destructive) {
                                        historyStore.delete(id: record.id)
                                        playDeleteHaptic()
                                    } label: {
                                        Label("删除", systemImage: "trash")
                                            .foregroundStyle(.white)
                                            .frame(maxWidth: .infinity, maxHeight: .infinity)
                                            .background(Color.red)
                                    }
                                    .tint(.red)
                                }
                        }
                    }
                    .listStyle(.insetGrouped)
                    .overlay {
                        if historyStore.records.isEmpty {
                            AppEmptyState(title: "暂无历史记录", symbol: "clock.arrow.circlepath", message: "计算、换算和汇率操作会保存在这里。")
                        }
                    }
                } else {
                    VStack(spacing: 12) {
                        Image(systemName: lockedSymbol)
                            .font(.system(size: 36, weight: .medium))
                            .foregroundStyle(.cyan)
                        Text(isAuthenticating ? "正在验证身份" : "历史记录已锁定")
                            .font(.title3.weight(.semibold))
                        Text(lockedMessage)
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                            .multilineTextAlignment(.center)
                        if !isAuthenticating {
                            Button("重新验证", action: retryAuthentication)
                                .appGlassButtonStyle(prominent: true)
                                .tint(.cyan)
                                .padding(.top, 4)
                        }
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .padding(24)
                }
            }
            .navigationTitle("历史")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    if isUnlocked {
                        Button {
                            playDeleteHaptic()
                            isClearConfirmationPresented = true
                        } label: {
                            Label("清空", systemImage: "trash")
                        }
                        .disabled(historyStore.records.isEmpty)
                        .tint(.orange)
                        .popover(
                            isPresented: $isClearConfirmationPresented,
                            attachmentAnchor: .rect(.bounds),
                            arrowEdge: .top
                        ) {
                            HistoryDeletePopover(
                                title: "清空全部历史记录？",
                                message: "这会删除所有计算、换算和汇率记录，且无法撤销。",
                                confirmTitle: "清空历史记录",
                                onConfirm: {
                                    historyStore.clear()
                                    isClearConfirmationPresented = false
                                    playDeleteHaptic()
                                },
                                onCancel: {
                                    isClearConfirmationPresented = false
                                }
                            )
                            .presentationCompactAdaptation(.popover)
                        }
                    }
                }
            }
        }
        .preferredColorScheme(.dark)
        .onAppear(perform: updateBiometryType)
    }

    private func playDeleteHaptic() {
        #if LEGACY_APP
        if hapticsEnabled { LegacyHaptics.play(.impact(weight: .heavy, intensity: 0.72)) }
        #else
        AppHapticPlayer.play(.impact(weight: .heavy, intensity: 0.72), enabled: hapticsEnabled)
        #endif
    }

    private func updateBiometryType() {
        let context = LAContext()
        var error: NSError?
        _ = context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &error)
        biometryType = context.biometryType
    }

}

private struct HistoryDeletePopover: View {
    let title: String
    let message: String
    let confirmTitle: String
    let onConfirm: () -> Void
    let onCancel: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(title).font(.headline)
            Text(message)
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
            Button(role: .destructive, action: onConfirm) {
                Label(confirmTitle, systemImage: "trash").frame(maxWidth: .infinity)
            }
            .buttonStyle(.borderedProminent)
            .tint(.red)
            Button("取消", action: onCancel).frame(maxWidth: .infinity)
        }
        .padding(18)
        .frame(width: 290)
    }
}

private struct HistoryRow: View {
    let record: HistoryRecord

    var body: some View {
        HStack(alignment: .top, spacing: 13) {
            Image(systemName: record.kind.symbol)
                .font(.system(size: 15, weight: .semibold))
                .foregroundStyle(.cyan)
                .frame(width: 34, height: 34)
                .background(.cyan.opacity(0.12), in: Circle())
            VStack(alignment: .leading, spacing: 5) {
                HStack {
                    Text(record.kind.title).font(.caption.weight(.semibold)).foregroundStyle(.cyan)
                    Spacer()
                    Text(record.createdAt.formatted(date: .abbreviated, time: .shortened))
                        .font(.caption2).foregroundStyle(.secondary)
                }
                Text(record.title)
                    .font(.system(size: 16, weight: .medium, design: .rounded))
                    .foregroundStyle(.primary)
                    .lineLimit(2)
                Text(record.detail)
                    .font(.system(size: 15, weight: .regular, design: .rounded))
                    .foregroundStyle(.white.opacity(0.7))
                    .lineLimit(2)
            }
        }
        .padding(.vertical, 6)
        .accessibilityElement(children: .combine)
    }
}
