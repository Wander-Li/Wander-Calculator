import SwiftUI
import CoreHaptics
import UIKit

@MainActor
enum AppHapticPlayer {
    private static let lightImpact = UIImpactFeedbackGenerator(style: .medium)
    private static let mediumImpact = UIImpactFeedbackGenerator(style: .medium)
    private static let heavyImpact = UIImpactFeedbackGenerator(style: .heavy)
    private static let notification = UINotificationFeedbackGenerator()

    static func play(_ feedback: AppHapticFeedback, enabled: Bool = true) {
        guard enabled else { return }
        let configuredLevel = UserDefaults.standard.object(forKey: "haptics.intensity") as? Double ?? 0.7
        let level = min(1, max(0.1, configuredLevel))

        switch feedback {
        case let .impact(weight, intensity):
            let generator: UIImpactFeedbackGenerator
            let deviceAdjustedIntensity = min(1, max(0.25, intensity * (1 + level) * 1.4))
            switch weight {
            case .light: generator = lightImpact
            case .medium: generator = mediumImpact
            case .heavy: generator = heavyImpact
            }
            generator.prepare()
            generator.impactOccurred(intensity: CGFloat(deviceAdjustedIntensity))
            generator.prepare()
        case .selection:
            lightImpact.prepare()
            lightImpact.impactOccurred(intensity: CGFloat(0.5 * level))
            lightImpact.prepare()
        case .start:
            mediumImpact.prepare()
            mediumImpact.impactOccurred(intensity: CGFloat(0.72 * level))
            mediumImpact.prepare()
        case .success:
            notification.prepare()
            notification.notificationOccurred(.success)
            notification.prepare()
        case .error:
            notification.prepare()
            notification.notificationOccurred(.error)
            notification.prepare()
        }
    }
}

enum AppHapticFeedback {
    enum Weight { case light, medium, heavy }
    case impact(weight: Weight, intensity: Double)
    case selection, start, success, error

    #if !LEGACY_APP
    var systemFeedback: SwiftUI.SensoryFeedback {
        let configuredLevel = UserDefaults.standard.object(forKey: "haptics.intensity") as? Double ?? 0.7
        let level = min(1, configuredLevel * 1.25)
        switch self {
        case let .impact(weight, intensity):
            switch weight {
            case .light: return SwiftUI.SensoryFeedback.impact(weight: .medium, intensity: min(1, intensity * level * 1.35))
            case .medium: return SwiftUI.SensoryFeedback.impact(weight: .medium, intensity: min(1, intensity * level * 1.2))
            case .heavy: return SwiftUI.SensoryFeedback.impact(weight: .heavy, intensity: min(1, intensity * level))
            }
        case .selection: return SwiftUI.SensoryFeedback.impact(weight: .medium, intensity: 0.42 * level)
        case .start: return SwiftUI.SensoryFeedback.impact(weight: .medium, intensity: 0.72 * level)
        case .success: return SwiftUI.SensoryFeedback.impact(weight: .heavy, intensity: 0.92 * level)
        case .error: return SwiftUI.SensoryFeedback.impact(weight: .heavy, intensity: level)
        }
    }
    #endif
}

enum HapticSupport {
    #if LEGACY_APP
    static let available = true
    #else
    static let available = CHHapticEngine.capabilitiesForHardware().supportsHaptics
    #endif
}

struct HapticsSettingsButton: View {
    @AppStorage("haptics.enabled") private var hapticsEnabled = true
    @AppStorage("haptics.intensity") private var hapticsIntensity = 0.7
    @State private var showingSettings = false

    var body: some View {
        Button { showingSettings = true } label: {
            Image(systemName: "hand.tap")
                .font(.system(size: 15, weight: .semibold))
                .foregroundStyle(hapticsEnabled ? Color.cyan : Color.white.opacity(0.35))
                .frame(width: 40, height: 40)
                .accessibilityLabel(hapticsEnabled ? "触觉反馈已开启，设置" : "触觉反馈已关闭，设置")
        }
        .appGlassButtonStyle()
        .tint(.white.opacity(0.12))
        .sensoryFeedback(.selection, trigger: showingSettings) { _, _ in hapticsEnabled && HapticSupport.available }
        .sheet(isPresented: $showingSettings) {
            AppNavigationContainer {
                Form {
                    Toggle("触觉反馈", isOn: $hapticsEnabled)
                        .disabled(!HapticSupport.available)
                    Section {
                        VStack(alignment: .leading, spacing: 10) {
                            HStack {
                                Text("触觉力度")
                                Spacer()
                                Text("\(Int(hapticsIntensity * 100))%")
                                    .foregroundStyle(.secondary)
                                    .monospacedDigit()
                            }
                            Slider(value: $hapticsIntensity, in: 0.1...1)
                                .disabled(!HapticSupport.available)
                            HStack {
                                Text("轻").font(.caption).foregroundStyle(.secondary)
                                Spacer()
                                Text("强").font(.caption).foregroundStyle(.secondary)
                            }
                        }
                        Button {
                            guard hapticsEnabled else { return }
                            AppHapticPlayer.play(.impact(weight: .heavy, intensity: 1), enabled: hapticsEnabled)
                        } label: {
                            Label("测试触感", systemImage: "hand.tap")
                        }
                        .disabled(!hapticsEnabled || !HapticSupport.available)
                    }
                    Section {
                        Text(HapticSupport.available
                             ? "此开关控制应用添加的触觉反馈。轻触用于按键和选择，较明显的反馈用于交换或计算结果。iPhone 系统设置也可以关闭触觉反馈。"
                             : "此 iPad 没有支持应用触觉反馈的机身触感硬件。交互仍会提供界面动画反馈；连接支持触觉反馈的配件时，由系统和配件管理触感。")
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                    }
                }
                .navigationTitle("触觉反馈")
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .confirmationAction) {
                        Button("完成") { showingSettings = false }
                    }
                }
            }
            .appSheetPresentation(compact: true)
        }
    }
}
