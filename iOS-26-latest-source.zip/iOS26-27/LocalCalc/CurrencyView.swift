import SwiftUI

struct CurrencyView: View {
    var keyboardFocus: FocusState<KeyboardInput?>.Binding
    @ObservedObject var historyStore: HistoryStore
    @State private var base = "CNY"
    @State private var quote = "USD"
    @State private var amount = "1"
    @State private var rates: [String: Double] = [:]
    @State private var rateDate: String?
    @State private var updatedAt: Date?
    @State private var loading = false
    @State private var errorMessage: String?
    private let rateSource = CurrencyRateSource.cfets
    @AppStorage("haptics.enabled") private var hapticsEnabled = true
    @State private var historyTask: Task<Void, Never>?
    private let currencies = ["CNY", "USD", "EUR", "GBP", "JPY", "KRW", "HKD", "SGD", "AUD", "CAD", "CHF", "INR", "THB", "NZD"]

    private var result: Double? {
        guard let direct = rates[quote] else { return nil }
        return (Double(amount) ?? 0) * direct
    }

    var body: some View {
        ScrollView {
        VStack(alignment: .leading, spacing: 18) {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text("EXCHANGE RATES").font(.system(size: 11, weight: .bold, design: .rounded)).tracking(2.2).foregroundStyle(.cyan)
                    Text("汇率").font(.system(size: 26, weight: .bold, design: .rounded))
                }
                Spacer()
                if keyboardFocus.wrappedValue == .currencyAmount { dismissKeyboardButton }
                HapticsSettingsButton()
            }
            Text("汇率在点击刷新时联网获取，数据可能有延迟，不用于交易结算。")
                .font(.system(size: 13)).foregroundStyle(.white.opacity(0.55)).fixedSize(horizontal: false, vertical: true)
            VStack(spacing: 14) {
                currencyCard(label: "金额", code: $base, isInput: true)
                Button { swap(&base, &quote); rates = [:]; rateDate = nil; emit(.impact(weight: .medium, intensity: 0.5)) } label: { Image(systemName: "arrow.up.arrow.down").font(.system(size: 17, weight: .bold)).frame(width: 46, height: 46) }.appGlassButtonStyle().tint(.cyan)
                currencyCard(label: "参考金额", code: $quote, isInput: false)
            }
            if let result { Text("\(amount) \(base) ≈ \(CalculatorView.format(result)) \(quote)").font(.system(size: 14, weight: .medium)).foregroundStyle(.cyan) }
            if let rateDate { Text("汇率日期：\(rateDate)").font(.footnote).foregroundStyle(.white.opacity(0.5)) }
            if let updatedAt { Text("获取时间：\(updatedAt.formatted(date: .omitted, time: .shortened))").font(.footnote).foregroundStyle(.white.opacity(0.42)) }
            if let errorMessage { Text(errorMessage).font(.footnote).foregroundStyle(.orange).fixedSize(horizontal: false, vertical: true) }
            Button(action: { Task { await refresh() } }) {
                HStack(spacing: 9) { if loading { ProgressView() } else { Image(systemName: "arrow.clockwise") }; Text(loading ? "正在获取" : "刷新参考汇率") }
                    .font(.system(size: 16, weight: .semibold)).frame(maxWidth: .infinity).frame(height: 54)
            }.disabled(loading).appGlassButtonStyle(prominent: true).tint(.cyan)
            Text("数据源：\(rateSource.title) · 通过 Frankfurter 提供")
                .font(.system(size: 11)).foregroundStyle(.white.opacity(0.42))
        }.padding(.horizontal, 20).padding(.top, 20).padding(.bottom, 24)
            .frame(maxWidth: 620).frame(maxWidth: .infinity)
        }
            .appScrollDismissesKeyboard()
            .appOnChange(of: amount) { _ in scheduleHistory() }
            .appOnChange(of: base) { _ in scheduleHistory() }
            .appOnChange(of: quote) { _ in scheduleHistory() }
            .toolbar {
                ToolbarItemGroup(placement: .keyboard) {
                    Spacer()
                    Button { dismissKeyboard() } label: {
                        Label("收起键盘", systemImage: "keyboard.chevron.compact.down")
                    }
                }
            }
    }

    private func currencyCard(label: String, code: Binding<String>, isInput: Bool) -> some View {
        HStack {
            VStack(alignment: .leading, spacing: 7) {
                Text(label).font(.caption).foregroundStyle(.white.opacity(0.5))
                if isInput { TextField("金额", text: $amount).focused(keyboardFocus, equals: .currencyAmount).keyboardType(.decimalPad).font(.system(size: 30, weight: .medium, design: .rounded)).monospacedDigit() }
                else { Text(result.map(CalculatorView.format) ?? "—").font(.system(size: 30, weight: .medium, design: .rounded)).monospacedDigit().lineLimit(1).minimumScaleFactor(0.5) }
            }
            Spacer()
            Menu { ForEach(currencies, id: \.self) { item in Button(item) { code.wrappedValue = item; rates = [:]; rateDate = nil; emit(.selection) } } } label: {
                HStack(spacing: 5) { Text(code.wrappedValue); Image(systemName: "chevron.down").font(.system(size: 9, weight: .bold)) }.font(.system(size: 15, weight: .semibold)).foregroundStyle(.cyan).padding(.horizontal, 12).padding(.vertical, 10).background(.white.opacity(0.08), in: Capsule())
            }
        }.padding(18).background(.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 22))
    }

    private var dismissKeyboardButton: some View {
        Button { dismissKeyboard() } label: {
            Image(systemName: "xmark").font(.system(size: 15, weight: .bold)).frame(width: 40, height: 40)
        }
        .appGlassButtonStyle().tint(.white.opacity(0.14)).accessibilityLabel("收起键盘")
    }

    @MainActor private func refresh() async {
        loading = true; errorMessage = nil; emit(.start); defer { loading = false }
        let endpoint = "https://api.frankfurter.dev/v2/providers/\(rateSource.providerKey)/rate/\(base.lowercased())/\(quote.lowercased())"
        guard let url = URL(string: endpoint) else { errorMessage = "汇率地址无效。"; return }
        do {
            var request = URLRequest(url: url); request.timeoutInterval = 15; request.cachePolicy = .reloadIgnoringLocalCacheData
            let (data, response) = try await URLSession.shared.data(for: request)
            guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else { throw URLError(.badServerResponse) }
            let payload = try JSONDecoder().decode(FrankfurterRateResponse.self, from: data)
            guard payload.base.uppercased() == base,
                  payload.quote.uppercased() == quote,
                  payload.rate.isFinite, payload.rate > 0 else { throw URLError(.cannotParseResponse) }
            rates = [quote: payload.rate]; rateDate = payload.date; updatedAt = .now; emit(.success)
            recordCurrencyHistory(amount: amount, rate: payload.rate, convertedAmount: (Double(amount) ?? 0) * payload.rate, baseCode: base, quoteCode: quote, sourceDate: payload.date)
        } catch {
            errorMessage = "无法从\(rateSource.title)获取 \(base)/\(quote) 汇率。请尝试其他来源或稍后重试。"; emit(.error)
        }
    }
    private func emit(_ feedback: AppHapticFeedback) {
        #if LEGACY_APP
        if hapticsEnabled { LegacyHaptics.play(feedback) }
        #else
        AppHapticPlayer.play(feedback, enabled: hapticsEnabled)
        #endif
    }
    private func dismissKeyboard() { emit(.selection); keyboardFocus.wrappedValue = nil }

    private func scheduleHistory() {
        historyTask?.cancel()
        guard let rate = rates[quote] else { return }
        let capturedAmount = amount
        let capturedBase = base
        let capturedQuote = quote
        let capturedRate = rate
        let capturedDate = rateDate
        let convertedAmount = (Double(amount) ?? 0) * rate
        historyTask = Task { @MainActor in
            do { try await Task.sleep(nanoseconds: 600_000_000) } catch { return }
            guard !Task.isCancelled else { return }
            recordCurrencyHistory(amount: capturedAmount, rate: capturedRate, convertedAmount: convertedAmount, baseCode: capturedBase, quoteCode: capturedQuote, sourceDate: capturedDate)
        }
    }

    private func recordCurrencyHistory(amount: String, rate: Double, convertedAmount: Double, baseCode: String, quoteCode: String, sourceDate: String?) {
        let rateDateText = sourceDate.map { " · 汇率日期 \($0)" } ?? ""
        historyStore.add(
            kind: .currency,
            title: "\(amount) \(baseCode) → \(quoteCode)",
            detail: "≈ \(CalculatorView.format(convertedAmount)) \(quoteCode) · 1 \(baseCode) = \(CalculatorView.format(rate)) \(quoteCode)\(rateDateText)"
        )
    }
}

private enum CurrencyRateSource {
    case cfets

    var title: String { "中国货币网（CFETS）" }
    var providerKey: String { "cfets" }
}

private struct FrankfurterRateResponse: Decodable {
    let base: String
    let quote: String
    let date: String
    let rate: Double
}
