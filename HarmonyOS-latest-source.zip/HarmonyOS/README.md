# 计算器 · HarmonyOS / OpenHarmony 原生版

版本 1.0.0。依据现有 iOS 26–27 工程 `LocalCalc/` 的功能移植，使用 ArkTS、ArkUI 与 Stage UIAbility，不含 WebView 或 Swift 运行时。

## 在 DevEco Studio 中打开

两个文件夹是独立工程，分别打开，不要把上层总文件夹当作工程：

| 工程目录 | 运行系统与 SDK | 原生界面 |
| --- | --- | --- |
| `HarmonyOS/` | 华为原生 HarmonyOS 6.1 / API 23 及以上；编译 SDK 6.1.0(23) | HDS 悬浮底部页签，原生 IMMERSIVE 沉浸光感，设备不支持时使用系统 ADAPTIVE 材质 |
| `OpenHarmony/` | OpenHarmony 标准系统 API 18 及以上，设备需提供 ArkUI | ArkUI Tabs、系统模糊材质、原生弹出菜单、原生滑动删除 |

华为版适用于原生鸿蒙应用体系，不是 HarmonyOS 4.x 的 Android APK。华为 HDS 沉浸光感不属于 OpenHarmony 公共 SDK；OpenHarmony 工程没有引用 `@kit.UIDesignKit`，不会把普通模糊宣传为华为专属沉浸光感。

1. 安装支持对应 SDK 的 DevEco Studio，并在 SDK 管理器安装上表的 SDK。OpenHarmony 工程需要 OpenHarmony SDK，不能只安装华为 HarmonyOS SDK。
2. 选择 **File → Open**，打开 `HarmonyOS` 或 `OpenHarmony` 文件夹，等待项目同步。可在 Project Structure 中选择本机对应 SDK 与构建工具版本；工程没有外部业务依赖。
3. 在 Signing Configs 中配置自己的鸿蒙开发者签名，选择真机运行。iOS 企业证书不能用于鸿蒙签名。
4. 使用 **Build → Build Hap(s)/APP(s) → Build Hap(s)** 打包。产物在 `entry/build/default/outputs/default/`；未配置签名时只能生成未签名构建产物。

当前交付为源码工程：本机没有 DevEco Studio、鸿蒙 SDK 或签名材料，因此**尚未完成 ArkTS/HAP 编译和真机验证，也没有生成可安装 HAP**。Node 数学逻辑测试不等同于鸿蒙编译通过。不要把源码压缩包改名为 HAP 安装。

## 功能

- 四个导航页签：计算、换算、汇率、历史。标准/科学模式在计算页切换，保留原版结构。
- 科学区完整的 5×6 按键：括号、mc/m+/m−/mr、2nd、平方/立方/任意次方、eˣ/10ˣ、倒数、平方根/立方根/任意次根、自然/常用对数、阶乘、三角/反三角与双曲/反双曲函数、e/π、EE、随机数、角度/弧度。只保留一个 AC。
- 标准区固定布局；小高度窗口与科学区支持滚动，预留导航区域。结果文字单行缩放，科学函数按键使用完整标签。
- 八类本地换算：长度、质量、温度、面积、体积、速度、时间、数据存储，二进制和十进制单位分别计算。
- 汇率仅点击刷新时请求 Frankfurter 的 **CFETS（中国货币网）提供方**，保留原版来源与说明。展示数据日期，缓存已获取币种组合以便离线查看；不是交易实时成交价。无定位权限、自动选源或其他来源。
- 三类操作统一保存到应用私有 Preferences，最多 500 条，异步串行落盘。切页会结束输入，换算/汇率输入防抖记录。
- 每次进入历史调用 HarmonyOS 官方用户认证弹窗，支持人脸、指纹和锁屏密码；设备未设置锁屏密码时按要求直接进入。离开历史或退后台立即清除界面中的解锁状态。系统处理凭据，应用不获取密码或生物数据。
- 历史向左滑显示红色删除；越过长距阈值松手直接删除。使用 ListItem 原生手势和稳定记录 ID，关闭回弹并使用渐隐过渡；全部清空需在垃圾桶锚定弹层中确认。
- 设备预置触感、10%–100% 力度滑块、测试触感、主界面开关亮/暗提示、独立本地按键音。优先使用设备支持的原生预置效果与强度，不支持时尝试短时振动；硬件不支持可调强度时由系统决定实际力度。滑块拖动期间只更新文字，不连续触发振动或保存。
- 手机/平板内容最大宽度、安全区、系统深色模式、系统键盘完成/收起、可复制结果、按钮无障碍描述。权限仅网络、振动与身份验证。

## 源码维护与检查

`shared/` 是共用功能源码。两个工程中的 `core/`、`components/`、`services/` 是完整副本，可以独立拷贝调试，不依赖上层路径。

修改共用源码后，从本目录运行：

```sh
node tools/materialize.mjs
node --test tests/core.test.mjs
node tools/check-projects.mjs
```

`materialize.mjs` 会重新生成两个工程中的源码、入口、资源和配置；它不会生成或写入证书。完成签名或改动目标配置后，不要直接重新生成覆盖自定义配置，请先保存这些改动。图标和音效已随本项目附带，不依赖 iOS 项目目录。

已检查范围：数学核心的严格 TypeScript 类型检查、7 组自动测试（运算优先级/科学函数/非法输入/数字格式/按键状态/全部单位/汇率载荷）、工程资源与配置一致性，以及 CFETS 默认 CNY/USD 接口响应。原生导航、沉浸光感、振动、系统认证和滑动动画需要 DevEco 与目标真机检查。

官方参考与真机检查清单见 `docs/适配说明.md`，本次检查记录见 `docs/交付检查.md`。

安装好 DevEco 与对应 SDK 后，也可运行 `tools/build-hap.sh HarmonyOS` 或 `tools/build-hap.sh OpenHarmony` 调用 DevEco 内置构建工具。
