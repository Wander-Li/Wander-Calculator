#!/bin/bash
set -euo pipefail
TASK_TARGET="${1:-HarmonyOS}"
case "$TASK_TARGET" in HarmonyOS|OpenHarmony) ;; *) echo 'Usage: tools/build-hap.sh HarmonyOS|OpenHarmony' >&2; exit 2;; esac
TASK_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TASK_IDE="${DEVECO_HOME:-/Applications/DevEco-Studio.app/Contents}"
TASK_NODE="$TASK_IDE/tools/node/bin/node"
TASK_HVIGOR="$TASK_IDE/tools/hvigor/bin/hvigorw.js"
if [ ! -x "$TASK_NODE" ] || [ ! -f "$TASK_HVIGOR" ]; then
  echo '请先安装 DevEco Studio 与对应 SDK，或设置 DEVECO_HOME 为其 Contents 路径。' >&2
  echo '也可在 DevEco Studio 中打开对应独立工程并使用 Build Hap(s)。' >&2
  exit 1
fi
cd "$TASK_ROOT/$TASK_TARGET"
exec "$TASK_NODE" "$TASK_HVIGOR" --mode module -p product=default -p module=entry@default -p buildMode=debug assembleHap --no-daemon
