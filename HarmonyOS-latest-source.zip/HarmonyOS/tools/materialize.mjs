import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const write = (file, content) => { fs.mkdirSync(path.dirname(file), {recursive:true}); fs.writeFileSync(file, typeof content === 'string' ? content : JSON.stringify(content,null,2)+'\n'); };
const symbols = {
  calculator: '<rect x="5" y="3" width="22" height="26" rx="6"/><path d="M10 10h12M11 17h.01M16 17h.01M21 17h.01M11 23h.01M16 23h.01M21 23h.01"/>',
  conversion: '<path d="M5 10h22l-6-6M27 22H5l6 6"/>',
  currency: '<path d="M5 4v23h23M9 20l6-7 5 3 7-10M21 6h6v6"/>',
  history: '<path d="M5 11a12 12 0 1 1-1 10M3 4v8h8M16 9v8l5 3"/>',
  touch: '<path d="M13 16V7a3 3 0 0 1 6 0v8M19 12a3 3 0 0 1 5 2v3M24 15a3 3 0 0 1 4 3v4c0 6-4 9-9 9-5 0-8-4-11-8l-3-5a3 3 0 0 1 5-3l3 3"/>',
  trash: '<path d="M5 8h22M12 8V4h8v4M8 8l1 21h14l1-21M13 13v11M19 13v11"/>',
};
const svg = body => `<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32" fill="none" stroke="#FFFFFF" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">${body}</svg>`;
const baseShell = (huawei) => `import { CalculatorPanel } from '../components/CalculatorPanel';
import { ConversionPanel } from '../components/ConversionPanel';
import { CurrencyPanel } from '../components/CurrencyPanel';
import { HistoryPanel } from '../components/HistoryPanel';
import { FeedbackPanel } from '../components/FeedbackPanel';
import { LocalStore } from '../services/LocalStore';
import { Feedback } from '../services/Feedback';
${huawei ? "import { HdsTabs, HdsTabsController, hdsMaterial } from '@kit.UIDesignKit';" : ''}

@Entry
@Component
struct Index {
  @State private selected: number = 0;
  @State private scientific: boolean = false;
  @State private showingSettings: boolean = false;
  @State private haptics: boolean = true;
  @State private intensity: number = 70;
  @State private sound: boolean = true;
  @State private warning: string = '';
  ${huawei ? '@State private immersive: boolean = false;\n  private controller: HdsTabsController = new HdsTabsController();' : 'private controller: TabsController = new TabsController();'}
  aboutToAppear(): void {
    const settings = LocalStore.get().settings;
    this.haptics = settings.haptics; this.intensity = settings.intensity; this.sound = settings.sound;
    this.warning = LocalStore.get().warning;
    ${huawei ? "try { this.immersive = hdsMaterial.getSystemMaterialTypes().indexOf(hdsMaterial.MaterialType.IMMERSIVE) >= 0; } catch (_) { this.immersive = false; }" : ''}
  }
  private title(): string { return ['计算器','单位换算','汇率','历史'][this.selected]; }
  @Builder
  private Header() {
    Row({ space: 10 }) {
      Column({ space: 4 }) {
        Text(['CALCULATOR','CONVERTER','EXCHANGE RATES','HISTORY'][this.selected]).fontSize(10).letterSpacing(2.2).fontColor('#42D9F5')
        Text(this.title()).fontSize(27).fontWeight(FontWeight.Bold).fontColor('#FFFFFF')
      }.alignItems(HorizontalAlign.Start).layoutWeight(1)
      Button({ type: ButtonType.Circle }) {
        Image($r('app.media.touch')).width(21).height(21).fillColor(this.haptics ? '#42D9F5' : '#626D78')
      }.width(44).height(44).backgroundColor(this.haptics ? '#15303D' : '#1A222B')
        .accessibilityText(this.haptics ? '触觉反馈已开启，打开设置' : '触觉反馈已关闭，打开设置')
        .onClick(() => { this.showingSettings = true; Feedback.get().haptic(); })
      if (this.selected === 0) {
        Button(this.scientific ? '科学' : '标准').height(44).fontSize(14).fontColor('#42D9F5')
          .backgroundColor('#1A2F3B').onClick(() => { this.scientific = !this.scientific; Feedback.get().haptic(); })
      }
    }.height(76).width('100%').padding({ left: 20, right: 20 })
  }
  @Builder
  private Settings() {
    FeedbackPanel({ haptics: $haptics, intensity: $intensity, sound: $sound })
  }
  @Builder
  private TabIcon(index: number, icon: Resource, name: string) {
    Column({ space: 3 }) {
      Image(icon).width(23).height(23).fillColor(this.selected === index ? '#42D9F5' : '#A4AFBB')
      Text(name).fontSize(11).fontColor(this.selected === index ? '#42D9F5' : '#A4AFBB')
    }.width('100%').height(56).justifyContent(FlexAlign.Center).accessibilityText(name)
  }
  build() {
    Column() {
      this.Header()
      if (this.warning) { Text(this.warning).fontColor('#FFAC48').fontSize(12).padding({ left: 20, right: 20 }) }
      ${huawei ? 'HdsTabs' : 'Tabs'}({ index: this.selected, controller: this.controller }) {
        TabContent() {
          Column() { CalculatorPanel({ scientific: $scientific }) }
            .width('100%').height('100%').padding({ left: 20, right: 20, bottom: ${huawei ? '94' : '4'} })
        }.tabBar(this.TabIcon(0, $r('app.media.calculator'), '计算'))
        TabContent() {
          Column() { ConversionPanel({ active: this.selected === 1 }) }.width('100%').height('100%').padding({ left: 20, right: 20, bottom: ${huawei ? '94' : '4'} })
        }.tabBar(this.TabIcon(1, $r('app.media.conversion'), '换算'))
        TabContent() {
          Column() { CurrencyPanel({ active: this.selected === 2 }) }.width('100%').height('100%').padding({ left: 20, right: 20, bottom: ${huawei ? '94' : '4'} })
        }.tabBar(this.TabIcon(2, $r('app.media.currency'), '汇率'))
        TabContent() {
          Column() { HistoryPanel({ active: this.selected === 3 }) }.width('100%').height('100%').padding({ left: 20, right: 20, bottom: ${huawei ? '94' : '4'} })
        }.tabBar(this.TabIcon(3, $r('app.media.history'), '历史'))
      }
      .layoutWeight(1).width('100%').barMode(BarMode.Fixed).barPosition(BarPosition.End)
      ${huawei ? `.barOverlap(true).barPosition(BarPosition.End)
      .barFloatingStyle({
        barWidth: { smallWidth: 320, mediumWidth: 460, largeWidth: 560 }, barBottomMargin: 12,
        systemMaterialEffect: { materialType: this.immersive ? hdsMaterial.MaterialType.IMMERSIVE : hdsMaterial.MaterialType.ADAPTIVE,
          materialLevel: this.immersive ? hdsMaterial.MaterialLevel.EXQUISITE : hdsMaterial.MaterialLevel.SMOOTH }
      })` : `.barHeight(68).barBackgroundColor('#192431').barBackgroundBlurStyle(BlurStyle.COMPONENT_THIN)`}
      .onChange((index: number) => { this.selected = index; Feedback.get().haptic(); })
    }.width('100%').height('100%').backgroundColor('#080D14')
      .bindSheet($$this.showingSettings, this.Settings(), {
        height: '72%', title: { title: '触觉与声音' }, showClose: true, backgroundColor: '#121A24'
      })
  }
}
`;
for (const target of ['HarmonyOS','OpenHarmony']) {
  const huawei = target === 'HarmonyOS';
  const dir = path.join(root,target);
  const main = path.join(dir,'entry/src/main');
  const ets = path.join(main,'ets');
  fs.mkdirSync(ets,{recursive:true});
  for (const group of ['core','services','components']) { fs.cpSync(path.join(root,'shared',group),path.join(ets,group),{recursive:true}); }
  write(path.join(ets,'entryability/EntryAbility.ets'), fs.readFileSync(path.join(root,'shared/EntryAbility.ets'),'utf8').replaceAll("from './services/", "from '../services/"));
  write(path.join(ets,'pages/Index.ets'),baseShell(huawei));
  const app = {app:{bundleName:huawei?'com.localcalc.harmony':'com.localcalc.openharmony', vendor:'LocalCalc', versionCode:1000000, versionName:'1.0.0', icon:'$media:app_icon',label:'$string:app_name'}};
  write(path.join(dir,'AppScope/app.json5'),app);
  write(path.join(dir,'AppScope/resources/base/element/string.json'),{string:[{name:'app_name',value:'计算器'}]});
  fs.mkdirSync(path.join(dir,'AppScope/resources/base/media'),{recursive:true});
  fs.copyFileSync(path.join(root,'shared/resources/app_icon.png'),path.join(dir,'AppScope/resources/base/media/app_icon.png'));
  const mediaDir = path.join(main,'resources/base/media'); fs.mkdirSync(mediaDir,{recursive:true});
  fs.copyFileSync(path.join(root,'shared/resources/app_icon.png'),path.join(mediaDir,'app_icon.png'));
  for (const [name, body] of Object.entries(symbols)) { write(path.join(mediaDir,name+'.svg'),svg(body)); }
  write(path.join(main,'resources/base/element/string.json'),{string:[{name:'module_desc',value:'本地计算器'},{name:'ability_desc',value:'计算、科学计算、单位换算、汇率与本地历史'},{name:'app_name',value:'计算器'},{name:'biometric_reason',value:'用于验证身份后查看本机计算历史'}]});
  write(path.join(main,'resources/base/element/color.json'),{color:[{name:'start_window_background',value:'#080D14'}]});
  write(path.join(main,'resources/base/profile/main_pages.json'),{src:['pages/Index']});
  fs.mkdirSync(path.join(main,'resources/rawfile'),{recursive:true});
  fs.copyFileSync(path.join(root,'shared/resources/keyclick.wav'),path.join(main,'resources/rawfile/keyclick.wav'));
  const module = {module:{name:'entry',type:'entry',description:'$string:module_desc',mainElement:'EntryAbility',deviceTypes:['phone','tablet'],deliveryWithInstall:true,installationFree:false,pages:'$profile:main_pages',abilities:[{name:'EntryAbility',srcEntry:'./ets/entryability/EntryAbility.ets',description:'$string:ability_desc',icon:'$media:app_icon',label:'$string:app_name',startWindowIcon:'$media:app_icon',startWindowBackground:'$color:start_window_background',exported:true,skills:[{entities:['entity.system.home'],actions:['action.system.home']}]}],requestPermissions:[{name:'ohos.permission.INTERNET'},{name:'ohos.permission.VIBRATE'},{name:'ohos.permission.ACCESS_BIOMETRIC',reason:'$string:biometric_reason',usedScene:{abilities:['EntryAbility'],when:'inuse'}}]}};
  if (huawei) { module.module.metadata = [{name:'ohos.arkui.UIMaterial.state',value:'enable'}]; }
  write(path.join(main,'module.json5'),module);
  const sdk = huawei ? '6.1.0(23)' : 18;
  const product = {name:'default',compatibleSdkVersion:sdk,targetSdkVersion:sdk,runtimeOS:huawei?'HarmonyOS':'OpenHarmony'};
  if (!huawei) { product.compileSdkVersion = sdk; }
  write(path.join(dir,'build-profile.json5'),{app:{products:[product],buildModeSet:[{name:'debug'},{name:'release'}]},modules:[{name:'entry',srcPath:'./entry',targets:[{name:'default',applyToProducts:['default']}]}]});
  write(path.join(dir,'entry/build-profile.json5'),{apiType:'stageMode',buildOption:{arkOptions:{runtimeOnly:{sources:[],packages:[]}}},buildOptionSet:[{name:'release',arkOptions:{obfuscation:{ruleOptions:{enable:false,files:['./obfuscation-rules.txt']}}}}],targets:[{name:'default'}]});
  write(path.join(dir,'entry/obfuscation-rules.txt'),'# Native ArkTS application. No obfuscation required for local debugging.\n');
  write(path.join(dir,'oh-package.json5'),{name:'localcalc-'+target.toLowerCase(),version:'1.0.0',description:'Local native calculator',modelVersion:'5.0.0',dependencies:{},devDependencies:{}});
  write(path.join(dir,'entry/oh-package.json5'),{name:'entry',version:'1.0.0',description:'Local calculator entry',main:'',author:'',license:'',dependencies:{}});
  write(path.join(dir,'hvigorfile.ts'),"import { appTasks } from '@ohos/hvigor-ohos-plugin';\nexport default { system: appTasks, plugins: [] };\n");
  write(path.join(dir,'entry/hvigorfile.ts'),"import { hapTasks } from '@ohos/hvigor-ohos-plugin';\nexport default { system: hapTasks, plugins: [] };\n");
  write(path.join(dir,'hvigor/hvigor-config.json5'),{modelVersion:'5.0.0',dependencies:{},execution:{analyze:'normal',daemon:true,incremental:true,parallel:true,typeCheck:true},logging:{level:'info'}});
  write(path.join(dir,'.gitignore'),'.hvigor/\noh_modules/\nbuild/\nentry/build/\nlocal.properties\n.idea/\n*.p12\n*.cer\n*.p7b\n');
}
console.log('Generated independent HarmonyOS and OpenHarmony DevEco projects.');
