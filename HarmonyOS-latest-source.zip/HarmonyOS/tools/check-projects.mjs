import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
let checked = 0;
const walk = dir => fs.readdirSync(dir,{withFileTypes:true}).flatMap(e => e.isDirectory() ? walk(path.join(dir,e.name)) : [path.join(dir,e.name)]);
for (const target of ['HarmonyOS','OpenHarmony']) {
  const dir=path.join(root,target); const files=walk(dir); const module=JSON.parse(fs.readFileSync(path.join(dir,'entry/src/main/module.json5'))).module;
  for(const file of files.filter(f=>f.endsWith('.json')||f.endsWith('.json5'))) { JSON.parse(fs.readFileSync(file)); checked++; }
  assert.deepEqual(module.requestPermissions.map(p=>p.name).sort(),['ohos.permission.ACCESS_BIOMETRIC','ohos.permission.INTERNET','ohos.permission.VIBRATE'].sort());
  const resourceFiles=files.filter(f=>f.includes('/resources/'));
  const names=new Set(resourceFiles.map(f=>path.basename(f).replace(/\.[^.]+$/,'')));
  for(const file of files.filter(f=>f.endsWith('.ets'))) {
    const text=fs.readFileSync(file,'utf8');
    if(target==='OpenHarmony') {assert.ok(!text.includes('@kit.UIDesignKit'));}
    for(const match of text.matchAll(/\$r\('app\.media\.([^']+)'\)/g)) {assert.ok(names.has(match[1]),`missing ${match[1]}`);checked++;}
    for(const match of text.matchAll(/from ['"]([.][^'"]+)['"]/g)) {assert.ok(['.ets','.ts'].some(ext=>fs.existsSync(path.resolve(path.dirname(file),match[1]+ext))),`missing ${match[1]}`);checked++;}
  }
  for(const group of ['core','components','services']) {
    for(const original of walk(path.join(root,'shared',group))) {
      const copy=path.join(dir,'entry/src/main/ets',group,path.relative(path.join(root,'shared',group),original));
      assert.equal(fs.readFileSync(original,'utf8'),fs.readFileSync(copy,'utf8'));checked++;
    }
  }
  const page=fs.readFileSync(path.join(dir,'entry/src/main/ets/pages/Index.ets'),'utf8');
  assert.ok(page.includes('HistoryPanel({ active: this.selected === 3 })'));
  if(target==='HarmonyOS') {assert.ok(page.includes('hdsMaterial.MaterialType.IMMERSIVE'));assert.ok(page.includes('.barFloatingStyle('));}
  assert.ok(fs.statSync(path.join(dir,'entry/src/main/resources/rawfile/keyclick.wav')).size>44);
}
console.log(`${checked} configuration, resource, import and source-copy checks passed. Native ArkTS compilation still requires its SDK.`);
