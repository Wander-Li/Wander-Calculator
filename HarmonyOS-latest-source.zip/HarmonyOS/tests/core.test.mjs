import test from 'node:test';
import assert from 'node:assert/strict';
import { evaluate, formatNumber, Calculator, BASIC_ROWS } from '../shared/core/Calculator.ts';
import { convert, UNIT_CATEGORIES } from '../shared/core/Units.ts';
import { validateQuote } from '../shared/core/Models.ts';
const near = (actual, expected) => assert.ok(Math.abs(actual - expected) <= Math.max(1, Math.abs(expected)) * 1e-10, `${actual} != ${expected}`);

test('arithmetic, precedence, unary signs, powers, implicit multiplication', () => {
  for (const [source, expected] of [['2+3×4',14], ['(2+3)×4',20], ['2^3^2',512], ['-2^2',-4], ['2^-3',0.125], ['2(3+4)',14], ['2pi',2*Math.PI], ['1E-6+2e-6',0.000003], ['5!+50%',120.5], ['0!',1], ['-(2+3)',-5]]) { near(evaluate(source), expected); }
});
test('all scientific functions, angle modes and real roots', () => {
  for (const [source, expected] of [['sin(30)',0.5],['cos(60)',0.5],['tan(45)',1],['asin(0.5)',30],['acos(0.5)',60],['atan(1)',45],['sinh(0)',0],['cosh(0)',1],['tanh(0)',0],['asinh(0)',0],['acosh(1)',0],['atanh(0)',0],['sqrt(81)',9],['root(-8,3)',-2],['root(81,4)',3],['ln(e)',1],['log10(1000)',3],['exp(0)',1]]) { near(evaluate(source),expected); }
  near(evaluate('sin(pi/2)',false),1);
});
test('invalid, non-finite and excessive nesting are rejected', () => {
  for (const source of ['', '1/0','sqrt(-1)','ln(0)','tan(90)','(-1)!','171!','root(-4,2)','root(4,0)','2+','1;process.exit()','9'.repeat(2049),'('.repeat(120)+'1'+')'.repeat(120)]) { assert.throws(() => evaluate(source), source); }
});
test('display formatting keeps values finite and handles very large/small numbers', () => {
  assert.equal(formatNumber(-0),'0'); assert.match(formatNumber(1e20),/e\+20/); assert.match(formatNumber(1e-10),/e-10/); assert.throws(() => formatNumber(Infinity));
});
test('calculator result continuation, new input, memory, sign, auto brackets', () => {
  const c = new Calculator(); c.press('2'); c.press('+'); c.press('3'); assert.equal(c.press('=').value,'5');
  c.press('×'); c.press('4'); assert.equal(c.press('=').value,'20');
  c.press('7'); assert.equal(c.display,'7'); c.press('m+'); c.press('AC'); c.press('mr'); assert.equal(c.press('=').value,'7');
  c.press('±'); assert.equal(c.press('=').value,'-7');
  c.press('AC'); c.press('sin'); c.press('3'); c.press('0'); assert.equal(c.press('=').value,'0.5');
  assert.equal(c.scientificRows().flat().filter(x => x==='AC').length,0);
  assert.equal(BASIC_ROWS.flat().filter(x=>x==='AC').length,1);
  assert.equal(c.scientificRows().flat().length,30);
});
test('temperature, binary/decimal data and all unit category round trips', () => {
  near(convert(32,2,1,0),0); near(convert(100,2,0,1),212); near(convert(0,2,0,2),273.15);
  near(convert(1,7,5,0),1024); near(convert(1,7,1,0),1000);
  UNIT_CATEGORIES.forEach((group,cat)=>group.units.forEach((_,index)=>near(convert(convert(123.45,cat,0,index),cat,index,0),123.45)));
  assert.throws(()=>convert(NaN,0,0,1)); assert.throws(()=>convert(1,99,0,1));
});
test('currency payload must match selected pair, valid date and positive finite rate',()=>{
  const good={base:'CNY',quote:'USD',rate:0.14,date:'2026-10-22',fetchedAt:0};
  assert.ok(validateQuote(good,'CNY','USD'));
  assert.ok(!validateQuote({...good,base:'EUR'},'CNY','USD'));
  for(const rate of [0,-1,NaN,Infinity]) {assert.ok(!validateQuote({...good,rate},'CNY','USD'));}
  assert.ok(!validateQuote({...good,date:'yesterday'},'CNY','USD'));
});
