export interface HistoryRecord {
  id: string;
  kind: string;
  title: string;
  detail: string;
  createdAt: number;
}
export interface Settings { haptics: boolean; intensity: number; sound: boolean; }
export interface RateQuote { base: string; quote: string; rate: number; date: string; fetchedAt: number; }
export const CURRENCIES: string[] = ['CNY','USD','EUR','GBP','JPY','KRW','HKD','SGD','AUD','CAD','CHF','INR','THB','NZD'];
export function validateQuote(data: RateQuote, base: string, quote: string): boolean {
  return data.base.toUpperCase() === base && data.quote.toUpperCase() === quote &&
    Number.isFinite(data.rate) && data.rate > 0 && /^\d{4}-\d{2}-\d{2}$/.test(data.date);
}
