export interface CalcResult { expression: string; value: string; }
interface Token { kind: string; text: string; value: number; }

export function formatNumber(value: number): string {
  if (!Number.isFinite(value)) { throw new Error('结果超出可计算范围'); }
  if (Object.is(value, -0) || value === 0) { return '0'; }
  if (Math.abs(value) >= 1e12 || Math.abs(value) < 1e-7) { return value.toExponential(8).replace(/\.?0+e/, 'e'); }
  return Number(value.toPrecision(12)).toString();
}

// Recursive descent; no eval, scripts, network or dynamic code execution.
class Parser {
  private tokens: Token[] = [];
  private index: number = 0;
  private degrees: boolean;
  private depth: number = 0;
  constructor(source: string, degrees: boolean) {
    this.degrees = degrees;
    const normalized = source.replace(/×/g, '*').replace(/÷/g, '/').replace(/−/g, '-').replace(/π/g, 'pi').replace(/\s/g, '');
    if (normalized.length === 0 || normalized.length > 2048) { throw new Error('请输入有效算式'); }
    let i = 0;
    while (i < normalized.length) {
      const remaining = normalized.slice(i);
      const number = remaining.match(/^(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?/);
      if (number !== null) {
        this.tokens.push({ kind: 'number', text: number[0], value: Number(number[0]) }); i += number[0].length; continue;
      }
      const name = remaining.match(/^[a-zA-Z]+\d*/);
      if (name !== null) {
        this.tokens.push({ kind: 'name', text: name[0].toLowerCase(), value: 0 }); i += name[0].length; continue;
      }
      const ch = normalized[i];
      if ('+-*/^%!(),'.indexOf(ch) < 0) { throw new Error('算式包含无效字符'); }
      this.tokens.push({ kind: ch, text: ch, value: 0 }); i++;
    }
    this.tokens.push({ kind: 'end', text: '', value: 0 });
  }
  private current(): Token { return this.tokens[this.index]; }
  private take(): Token { const t = this.current(); this.index++; return t; }
  private accept(kind: string): boolean { if (this.current().kind !== kind) { return false; } this.index++; return true; }
  private expect(kind: string): void { if (!this.accept(kind)) { throw new Error('请检查括号与算式'); } }
  run(): number {
    const result = this.addition();
    if (this.current().kind !== 'end' || !Number.isFinite(result)) { throw new Error('算式无效或结果超出范围'); }
    return result;
  }
  private addition(): number {
    let x = this.multiplication();
    while (this.current().kind === '+' || this.current().kind === '-') {
      const op = this.take().kind; const y = this.multiplication(); x = op === '+' ? x + y : x - y;
    }
    return x;
  }
  private multiplication(): number {
    let x = this.unary();
    while (true) {
      const op = this.current().kind;
      const implicit = op === '(' || op === 'name' || op === 'number';
      if (op !== '*' && op !== '/' && !implicit) { break; }
      if (!implicit) { this.take(); }
      const y = this.unary();
      if (op === '/' && y === 0) { throw new Error('不能除以零'); }
      x = op === '/' ? x / y : x * y;
    }
    return x;
  }
  private enter(): void { this.depth++; if (this.depth > 96) { throw new Error('算式嵌套过深'); } }
  private unary(): number {
    this.enter();
    let value: number;
    if (this.accept('-')) { value = -this.unary(); }
    else if (this.accept('+')) { value = this.unary(); }
    else { value = this.power(); }
    this.depth--; return value;
  }
  private power(): number {
    let x = this.postfix();
    if (this.accept('^')) { x = Math.pow(x, this.unary()); }
    return x;
  }
  private postfix(): number {
    let x = this.primary();
    while (this.current().kind === '%' || this.current().kind === '!') {
      if (this.take().kind === '%') { x /= 100; }
      else {
        if (x < 0 || x > 170 || Math.floor(x) !== x) { throw new Error('阶乘只支持 0–170 的整数'); }
        let product = 1; for (let n = 2; n <= x; n++) { product *= n; } x = product;
      }
    }
    return x;
  }
  private primary(): number {
    const token = this.take();
    if (token.kind === 'number') { return token.value; }
    if (token.kind === '(') { const x = this.addition(); this.expect(')'); return x; }
    if (token.kind !== 'name') { throw new Error('算式尚未完成'); }
    const name = token.text;
    if (name === 'pi') { return Math.PI; }
    if (name === 'e') { return Math.E; }
    this.expect('('); const raw = this.addition();
    if (name === 'root') {
      this.expect(','); const n = this.addition(); this.expect(')');
      if (n === 0) { throw new Error('根指数不能为零'); }
      if (raw < 0) {
        if (Math.floor(n) !== n || Math.abs(n % 2) !== 1) { throw new Error('负数不能开偶数次实数根'); }
        return -Math.pow(-raw, 1 / n);
      }
      return Math.pow(raw, 1 / n);
    }
    this.expect(')');
    const rad = this.degrees ? raw * Math.PI / 180 : raw;
    const inv = this.degrees ? 180 / Math.PI : 1;
    switch (name) {
      case 'sin': return Math.sin(rad);
      case 'cos': return Math.cos(rad);
      case 'tan': if (Math.abs(Math.cos(rad)) < 1e-14) { throw new Error('此角度的正切未定义'); } return Math.tan(rad);
      case 'asin': return Math.asin(raw) * inv;
      case 'acos': return Math.acos(raw) * inv;
      case 'atan': return Math.atan(raw) * inv;
      case 'sinh': return Math.sinh(raw);
      case 'cosh': return Math.cosh(raw);
      case 'tanh': return Math.tanh(raw);
      case 'asinh': return Math.asinh(raw);
      case 'acosh': return Math.acosh(raw);
      case 'atanh': return Math.atanh(raw);
      case 'ln': return Math.log(raw);
      case 'log': case 'log10': return Math.log10(raw);
      case 'sqrt': return Math.sqrt(raw);
      case 'exp': return Math.exp(raw);
      default: throw new Error('未知函数');
    }
  }
}
export function evaluate(source: string, degrees: boolean = true): number { return new Parser(source, degrees).run(); }

export class Calculator {
  expression: string = '';
  display: string = '0';
  degrees: boolean = true;
  second: boolean = false;
  memory: number = 0;
  error: string = '';
  private completed: boolean = false;
  scientificRows(): string[][] {
    return [
      ['(', ')', 'mc', 'm+', 'm−', 'mr'],
      ['2nd', 'x²', 'x³', 'xʸ', 'eˣ', '10ˣ'],
      ['1/x', '²√x', '³√x', 'ʸ√x', 'ln', 'log₁₀'],
      ['x!', this.second ? 'asin' : 'sin', this.second ? 'acos' : 'cos', this.second ? 'atan' : 'tan', 'e', 'EE'],
      ['Rand', this.second ? 'asinh' : 'sinh', this.second ? 'acosh' : 'cosh', this.second ? 'atanh' : 'tanh', 'π', this.degrees ? 'Rad' : 'Deg']
    ];
  }
  press(key: string): CalcResult | undefined {
    this.error = '';
    try {
      if (key === 'AC') { this.expression = ''; this.display = '0'; this.completed = false; return undefined; }
      if (key === 'Rad' || key === 'Deg') { this.degrees = !this.degrees; return undefined; }
      if (key === '2nd') { this.second = !this.second; return undefined; }
      if (key === 'mc') { this.memory = 0; return undefined; }
      if (key === 'm+' || key === 'm−') {
        this.memory += evaluate(this.expression || this.display, this.degrees) * (key === 'm+' ? 1 : -1);
        if (!Number.isFinite(this.memory)) { this.memory = 0; throw new Error('存储值超出范围'); }
        return undefined;
      }
      if (key === '=') {
        let source = this.expression || this.display;
        const opens = (source.match(/\(/g) || []).length;
        const closes = (source.match(/\)/g) || []).length;
        if (opens > closes) { source += ')'.repeat(opens - closes); }
        const value = formatNumber(evaluate(source, this.degrees));
        this.display = value; this.expression = ''; this.completed = true;
        return { expression: source, value: value };
      }
      const continuation = ['+', '−', '×', '÷', '%', 'x!', 'x²', 'x³', 'xʸ', '1/x', '²√x', '³√x', 'ʸ√x', 'eˣ', '10ˣ', '±'].indexOf(key) >= 0;
      if (this.completed) { this.expression = continuation ? this.display : ''; this.completed = false; }
      switch (key) {
        case '⌫': this.expression = this.expression.slice(0, -1); break;
        case 'mr': this.expression += '(' + formatNumber(this.memory) + ')'; break;
        case '±': this.expression = this.expression.startsWith('−(') && this.expression.endsWith(')') ? this.expression.slice(2, -1) : '−(' + (this.expression || '0') + ')'; break;
        case 'x²': this.expression += '^2'; break;
        case 'x³': this.expression += '^3'; break;
        case 'xʸ': this.expression += '^'; break;
        case 'x!': this.expression += '!'; break;
        case '1/x': this.expression = '1/(' + (this.expression || '0') + ')'; break;
        case '²√x': this.expression = 'sqrt(' + (this.expression || '0') + ')'; break;
        case '³√x': this.expression = 'root(' + (this.expression || '0') + ',3)'; break;
        case 'ʸ√x': this.expression = 'root(' + (this.expression || '0') + ','; break;
        case 'eˣ': this.expression = 'exp(' + (this.expression || '0') + ')'; break;
        case '10ˣ': this.expression = '10^(' + (this.expression || '0') + ')'; break;
        case 'EE': this.expression += 'E'; break;
        case 'Rand': this.expression += Math.random().toPrecision(10); break;
        case 'log₁₀': this.expression += 'log10('; break;
        case 'sin': case 'cos': case 'tan': case 'asin': case 'acos': case 'atan':
        case 'sinh': case 'cosh': case 'tanh': case 'asinh': case 'acosh': case 'atanh': case 'ln':
          this.expression += key + '('; break;
        default: this.expression += key; break;
      }
      if (this.expression.length > 2048) { this.expression = this.expression.slice(0, 2048); throw new Error('算式过长'); }
      this.display = this.expression || '0';
    } catch (err) { this.error = (err as Error).message; this.display = '错误'; }
    return undefined;
  }
}
export const BASIC_ROWS: string[][] = [['AC', '±', '%', '÷'], ['7', '8', '9', '×'], ['4', '5', '6', '−'], ['1', '2', '3', '+'], ['⌫', '0', '.', '=']];
