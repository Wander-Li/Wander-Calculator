export interface Unit { name: string; factor: number; }
export interface UnitCategory { name: string; units: Unit[]; }
export const UNIT_CATEGORIES: UnitCategory[] = [
  { name: '长度', units: [{name:'米',factor:1},{name:'公里',factor:1000},{name:'厘米',factor:0.01},{name:'毫米',factor:0.001},{name:'英寸',factor:0.0254},{name:'英尺',factor:0.3048},{name:'码',factor:0.9144},{name:'英里',factor:1609.344},{name:'海里',factor:1852}] },
  { name: '质量', units: [{name:'千克',factor:1},{name:'克',factor:0.001},{name:'毫克',factor:0.000001},{name:'吨',factor:1000},{name:'磅',factor:0.45359237},{name:'盎司',factor:0.028349523125}] },
  { name: '温度', units: [{name:'摄氏度',factor:1},{name:'华氏度',factor:1},{name:'开尔文',factor:1}] },
  { name: '面积', units: [{name:'平方米',factor:1},{name:'平方公里',factor:1e6},{name:'公顷',factor:1e4},{name:'平方英尺',factor:0.09290304},{name:'英亩',factor:4046.8564224}] },
  { name: '体积', units: [{name:'升',factor:1},{name:'毫升',factor:0.001},{name:'立方米',factor:1000},{name:'美制加仑',factor:3.785411784},{name:'杯',factor:0.2365882365}] },
  { name: '速度', units: [{name:'米/秒',factor:1},{name:'公里/时',factor:1/3.6},{name:'英里/时',factor:0.44704},{name:'节',factor:0.5144444444444445}] },
  { name: '时间', units: [{name:'秒',factor:1},{name:'分钟',factor:60},{name:'小时',factor:3600},{name:'天',factor:86400},{name:'周',factor:604800}] },
  { name: '数据', units: [{name:'字节',factor:1},{name:'KB',factor:1000},{name:'MB',factor:1e6},{name:'GB',factor:1e9},{name:'TB',factor:1e12},{name:'KiB',factor:1024},{name:'MiB',factor:1048576},{name:'GiB',factor:1073741824}] }
];
export function convert(value: number, category: number, from: number, to: number): number {
  if (!Number.isFinite(value)) { throw new Error('请输入有效数值'); }
  const group = UNIT_CATEGORIES[category];
  if (!group || !group.units[from] || !group.units[to]) { throw new Error('单位无效'); }
  let result: number;
  if (group.name === '温度') {
    const c = from === 1 ? (value - 32) * 5 / 9 : (from === 2 ? value - 273.15 : value);
    result = to === 1 ? c * 9 / 5 + 32 : (to === 2 ? c + 273.15 : c);
  } else { result = value * group.units[from].factor / group.units[to].factor; }
  if (!Number.isFinite(result)) { throw new Error('换算结果超出范围'); }
  return result;
}
