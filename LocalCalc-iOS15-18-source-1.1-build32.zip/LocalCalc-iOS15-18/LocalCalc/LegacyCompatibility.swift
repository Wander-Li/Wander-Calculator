import SwiftUI
#if LEGACY_APP
import UIKit
#endif

extension View {
    func appOnChange<Value: Equatable>(of value: Value, perform action: @escaping (Value) -> Void) -> some View {
        #if LEGACY_APP
        self.onChange(of: value, perform: action)
        #else
        self.onChange(of: value) { _, newValue in action(newValue) }
        #endif
    }

    @ViewBuilder
    func appGlassButtonStyle(prominent: Bool = false) -> some View {
        #if LEGACY_APP
        if prominent {
            self.buttonStyle(.borderedProminent)
        } else {
            self.buttonStyle(.bordered)
        }
        #else
        if prominent {
            self.buttonStyle(.glassProminent)
        } else {
            self.buttonStyle(.glass)
        }
        #endif
    }

    @ViewBuilder
    func appScrollDismissesKeyboard() -> some View {
        #if LEGACY_APP
        self
        #else
        self.scrollDismissesKeyboard(.interactively)
        #endif
    }

    @ViewBuilder
    func appScrollIndicatorsHidden() -> some View {
        #if LEGACY_APP
        self
        #else
        self.scrollIndicators(.hidden)
        #endif
    }

    @ViewBuilder
    func appSheetPresentation(compact: Bool = false) -> some View {
        #if LEGACY_APP
        self
        #else
        if compact {
            self.presentationDetents([.medium])
        } else {
            self.presentationDetents([.medium, .large]).presentationDragIndicator(.visible)
        }
        #endif
    }
}

struct AppNavigationContainer<Content: View>: View {
    @ViewBuilder var content: Content

    var body: some View {
        #if LEGACY_APP
        NavigationView { content }
        #else
        NavigationStack { content }
        #endif
    }
}

struct AppEmptyState: View {
    let title: String
    let symbol: String
    var message: String? = nil

    var body: some View {
        #if LEGACY_APP
        VStack(spacing: 10) {
            Image(systemName: symbol).font(.system(size: 32)).foregroundColor(.secondary)
            Text(title).font(.headline)
            if let message { Text(message).font(.footnote).foregroundColor(.secondary).multilineTextAlignment(.center) }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .padding(24)
        #else
        if let message {
            ContentUnavailableView(title, systemImage: symbol, description: Text(message))
        } else {
            ContentUnavailableView(title, systemImage: symbol)
        }
        #endif
    }
}

#if LEGACY_APP
enum SensoryFeedback {
    enum Weight: Equatable { case light, medium, heavy }
    case impact(weight: Weight, intensity: Double)
    case selection, start, success, error
}

enum LegacyHaptics {
    private static let lightImpact = UIImpactFeedbackGenerator(style: .light)
    private static let mediumImpact = UIImpactFeedbackGenerator(style: .medium)
    private static let heavyImpact = UIImpactFeedbackGenerator(style: .heavy)
    private static let notification = UINotificationFeedbackGenerator()

    static func prepare() {
        lightImpact.prepare()
        mediumImpact.prepare()
        heavyImpact.prepare()
        notification.prepare()
    }

    static func play(_ feedback: SensoryFeedback) {
        let configuredLevel = UserDefaults.standard.object(forKey: "haptics.intensity") as? Double ?? 0.7
        let level = min(max(configuredLevel, 0.1), 1)
        switch feedback {
        case let .impact(weight, intensity):
            let generator: UIImpactFeedbackGenerator
            switch weight {
            case .light: generator = lightImpact
            case .medium: generator = mediumImpact
            case .heavy: generator = heavyImpact
            }
            generator.prepare()
            let requested = min(max(intensity, 0), 1)
            let base = max(requested, weight == .heavy ? 0.72 : 0.38)
            let strength = min(1, base * (0.65 + level * 0.85))
            generator.impactOccurred(intensity: CGFloat(strength))
            DispatchQueue.main.async { generator.prepare() }
        case .selection:
            mediumImpact.prepare()
            mediumImpact.impactOccurred(intensity: CGFloat(0.35 + level * 0.6))
            DispatchQueue.main.async { mediumImpact.prepare() }
        case .start:
            mediumImpact.prepare()
            mediumImpact.impactOccurred(intensity: CGFloat(0.35 + level * 0.6))
            DispatchQueue.main.async { mediumImpact.prepare() }
        case .success:
            notification.prepare()
            notification.notificationOccurred(.success)
            DispatchQueue.main.async { notification.prepare() }
        case .error:
            notification.prepare()
            notification.notificationOccurred(.error)
            DispatchQueue.main.async { notification.prepare() }
        }
    }
}

extension View {
    func sensoryFeedback<Value: Equatable>(trigger: Value, _ feedback: @escaping () -> SensoryFeedback?) -> some View {
        onChange(of: trigger) { _ in
            if let feedback = feedback() { LegacyHaptics.play(feedback) }
        }
    }

    func sensoryFeedback<Value: Equatable>(_ feedback: SensoryFeedback, trigger: Value, condition: @escaping (Value, Value) -> Bool) -> some View {
        onChange(of: trigger) { value in
            if condition(value, value) { LegacyHaptics.play(feedback) }
        }
    }
}
#endif
