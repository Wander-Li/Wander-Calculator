import SwiftUI
import CoreHaptics

enum HapticSupport {
    #if LEGACY_APP
    static let available = true
    #else
    static let available = CHHapticEngine.capabilitiesForHardware().supportsHaptics
    #endif
}

struct HapticsSettingsButton: View {
    @AppStorage("haptics.enabled") private var hapticsEnabled = true
    @AppStorage("haptics.intensity") private var hapticsIntensity = 0.7
    @State private var intensityDraft = 0.7
    @State private var showingSettings = false

    var body: some View {
        Button { showingSettings = true } label: {
            Image(systemName: "hand.tap")
                .font(.system(size: 15, weight: .semibold))
                .foregroundColor(hapticsEnabled ? .cyan : .white.opacity(0.35))
                .frame(width: 40, height: 40)
                .accessibilityLabel(hapticsEnabled ? "触觉反馈已开启，设置" : "触觉反馈已关闭，设置")
        }
        .appGlassButtonStyle()
        .tint(.white.opacity(0.12))
        .sensoryFeedback(.selection, trigger: showingSettings) { _, _ in hapticsEnabled && HapticSupport.available }
        .sheet(isPresented: $showingSettings) {
            AppNavigationContainer {
                Form {
                    Toggle("触觉反馈", isOn: $hapticsEnabled)
                        .disabled(!HapticSupport.available)
                    #if LEGACY_APP
                    Section {
                        VStack(alignment: .leading, spacing: 10) {
                            HStack {
                                Text("触觉力度")
                                Spacer()
                                Text("\(Int(intensityDraft * 100))%")
                                    .foregroundColor(.secondary)
                                    .monospacedDigit()
                            }
                            Slider(value: $intensityDraft, in: 0.1...1, onEditingChanged: { isEditing in
                                if !isEditing { hapticsIntensity = intensityDraft }
                            })
                                .disabled(!HapticSupport.available)
                            HStack {
                                Text("轻").font(.caption).foregroundColor(.secondary)
                                Spacer()
                                Text("强").font(.caption).foregroundColor(.secondary)
                            }
                        }
                        Button {
                            guard hapticsEnabled else { return }
                            hapticsIntensity = intensityDraft
                            LegacyHaptics.play(.impact(weight: .heavy, intensity: 1))
                        } label: {
                            Label("测试触感", systemImage: "hand.tap")
                        }
        .disabled(!hapticsEnabled || !HapticSupport.available)
                    }
                    #endif
                    Section {
                        Text(HapticSupport.available
                             ? "此开关控制应用添加的触觉反馈。轻触用于按键和选择，较明显的反馈用于交换或计算结果。iPhone 系统设置也可以关闭触觉反馈。"
                             : "此 iPad 没有支持应用触觉反馈的机身触感硬件。交互仍会提供界面动画反馈；连接支持触觉反馈的配件时，由系统和配件管理触感。")
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                    }
                }
                .navigationTitle("触觉反馈")
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .confirmationAction) {
                        Button("完成") { showingSettings = false }
                    }
                }
            }
            .onAppear { intensityDraft = hapticsIntensity }
            .appSheetPresentation(compact: true)
        }
    }
}
