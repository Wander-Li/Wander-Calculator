import SwiftUI

struct ConverterView: View {
    var keyboardFocus: FocusState<KeyboardInput?>.Binding
    @ObservedObject var historyStore: HistoryStore
    @State private var category: UnitCategory = .length
    @State private var amount = "1"
    @State private var from = "公里"
    @State private var to = "英里"
    @AppStorage("haptics.enabled") private var hapticsEnabled = true
    @State private var historyTask: Task<Void, Never>?

    private var input: Double { Double(amount) ?? 0 }
    private var output: Double { category.convert(input, from: from, to: to) }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                header
                Picker("类别", selection: $category) { ForEach(UnitCategory.allCases) { Text($0.title).tag($0) } }
                    .pickerStyle(.segmented).appOnChange(of: category) { value in from = value.units[0]; to = value.units[min(1, value.units.count - 1)] }
                VStack(spacing: 14) {
                    HStack {
                        VStack(alignment: .leading, spacing: 7) { Text("数值").font(.caption).foregroundStyle(.white.opacity(0.5)); TextField("数值", text: $amount).focused(keyboardFocus, equals: .converterAmount).keyboardType(.decimalPad).font(.system(size: 30, weight: .medium, design: .rounded)).monospacedDigit() }
                        Spacer(); unitMenu(selection: $from)
                    }.padding(18).background(.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 22))
                    Button { swap(&from, &to); emit(.impact(weight: .medium, intensity: 0.5)) } label: { Image(systemName: "arrow.up.arrow.down").font(.system(size: 17, weight: .bold)).frame(width: 46, height: 46) }.appGlassButtonStyle().tint(.cyan)
                    HStack {
                        VStack(alignment: .leading, spacing: 7) { Text("结果").font(.caption).foregroundStyle(.white.opacity(0.5)); Text(CalculatorView.format(output)).font(.system(size: 30, weight: .medium, design: .rounded)).monospacedDigit().lineLimit(1).minimumScaleFactor(0.5) }
                        Spacer(); unitMenu(selection: $to)
                    }.padding(18).background(.cyan.opacity(0.12), in: RoundedRectangle(cornerRadius: 22))
                }
                Text("所有换算在设备本地完成。无需网络。").font(.footnote).foregroundStyle(.white.opacity(0.48)).padding(.top, 2)
            }
            .padding(.horizontal, 20).padding(.top, 20).padding(.bottom, 24)
            .frame(maxWidth: 620).frame(maxWidth: .infinity)
        }
        .appScrollDismissesKeyboard()
        .appOnChange(of: amount) { _ in scheduleHistory() }
        .appOnChange(of: from) { _ in scheduleHistory() }
        .appOnChange(of: to) { _ in scheduleHistory() }
        .appOnChange(of: category) { _ in scheduleHistory() }
        .toolbar {
            ToolbarItemGroup(placement: .keyboard) {
                Spacer()
                Button { dismissKeyboard() } label: {
                    Label("收起键盘", systemImage: "keyboard.chevron.compact.down")
                }
            }
        }
    }

    private var header: some View {
            HStack { VStack(alignment: .leading, spacing: 4) { Text("CONVERTER").font(.system(size: 11, weight: .bold, design: .rounded)).tracking(2.2).foregroundStyle(.cyan); Text("单位换算").font(.system(size: 26, weight: .bold, design: .rounded)) }; Spacer(); if keyboardFocus.wrappedValue == .converterAmount { dismissKeyboardButton }; HapticsSettingsButton(); Image(systemName: "arrow.left.arrow.right").font(.title3).foregroundStyle(.cyan).padding(12) }
    }
    private var dismissKeyboardButton: some View {
        Button { dismissKeyboard() } label: {
            Image(systemName: "xmark").font(.system(size: 15, weight: .bold)).frame(width: 40, height: 40)
        }
        .appGlassButtonStyle().tint(.white.opacity(0.14)).accessibilityLabel("收起键盘")
    }
    private func unitMenu(selection: Binding<String>) -> some View {
        Menu { ForEach(category.units, id: \.self) { unit in Button(unit) { selection.wrappedValue = unit; emit(.selection) } } } label: {
            HStack(spacing: 5) { Text(selection.wrappedValue); Image(systemName: "chevron.down").font(.system(size: 9, weight: .bold)) }.font(.system(size: 15, weight: .semibold)).foregroundStyle(.cyan).padding(.horizontal, 12).padding(.vertical, 10).background(.white.opacity(0.08), in: Capsule())
        }
    }
    private func emit(_ feedback: SensoryFeedback) {
        if hapticsEnabled { LegacyHaptics.play(feedback) }
    }
    private func dismissKeyboard() { emit(.selection); keyboardFocus.wrappedValue = nil }

    private func scheduleHistory() {
        historyTask?.cancel()
        guard Double(amount) != nil else { return }
        let capturedAmount = amount
        let capturedFrom = from
        let capturedTo = to
        let capturedCategory = category.title
        let capturedOutput = category.convert(Double(amount) ?? 0, from: from, to: to)
        historyTask = Task { @MainActor in
            do { try await Task.sleep(nanoseconds: 600_000_000) } catch { return }
            guard !Task.isCancelled else { return }
            historyStore.add(
                kind: .conversion,
                title: "\(capturedAmount) \(capturedFrom) → \(capturedTo)",
                detail: "\(CalculatorView.format(capturedOutput)) \(capturedTo) · \(capturedCategory)"
            )
        }
    }
}

private enum UnitCategory: String, CaseIterable, Identifiable {
    case length, mass, temperature, area, volume, speed, time, data
    var id: String { rawValue }
    var title: String { switch self { case .length: "长度"; case .mass: "质量"; case .temperature: "温度"; case .area: "面积"; case .volume: "体积"; case .speed: "速度"; case .time: "时间"; case .data: "数据" } }
    var units: [String] { switch self {
        case .length: ["米", "公里", "厘米", "毫米", "英寸", "英尺", "码", "英里", "海里"]
        case .mass: ["千克", "克", "毫克", "吨", "磅", "盎司"]
        case .temperature: ["摄氏度", "华氏度", "开尔文"]
        case .area: ["平方米", "平方公里", "公顷", "平方英尺", "英亩"]
        case .volume: ["升", "毫升", "立方米", "美制加仑", "杯"]
        case .speed: ["米/秒", "公里/时", "英里/时", "节"]
        case .time: ["秒", "分钟", "小时", "天", "周"]
        case .data: ["字节", "KB", "MB", "GB", "TB", "KiB", "MiB", "GiB"]
    } }
    func convert(_ value: Double, from: String, to: String) -> Double {
        if self == .temperature {
            let c: Double
            switch from { case "华氏度": c = (value - 32) * 5 / 9; case "开尔文": c = value - 273.15; default: c = value }
            switch to { case "华氏度": return c * 9 / 5 + 32; case "开尔文": return c + 273.15; default: return c }
        }
        let factors: [String: Double]
        switch self {
        case .length: factors = ["米":1, "公里":1000, "厘米":0.01, "毫米":0.001, "英寸":0.0254, "英尺":0.3048, "码":0.9144, "英里":1609.344, "海里":1852]
        case .mass: factors = ["千克":1, "克":0.001, "毫克":0.000001, "吨":1000, "磅":0.45359237, "盎司":0.028349523125]
        case .area: factors = ["平方米":1, "平方公里":1e6, "公顷":1e4, "平方英尺":0.09290304, "英亩":4046.8564224]
        case .volume: factors = ["升":1, "毫升":0.001, "立方米":1000, "美制加仑":3.785411784, "杯":0.2365882365]
        case .speed: factors = ["米/秒":1, "公里/时":1/3.6, "英里/时":0.44704, "节":0.514444444]
        case .time: factors = ["秒":1, "分钟":60, "小时":3600, "天":86400, "周":604800]
        case .data: factors = ["字节":1, "KB":1000, "MB":1e6, "GB":1e9, "TB":1e12, "KiB":1024, "MiB":1048576, "GiB":1073741824]
        case .temperature: factors = [:]
        }
        return value * (factors[from] ?? 1) / (factors[to] ?? 1)
    }
}
