import Foundation
import Combine

enum HistoryKind: String, Codable, CaseIterable, Identifiable {
    case calculation
    case conversion
    case currency

    var id: String { rawValue }

    var title: String {
        switch self {
        case .calculation: "计算"
        case .conversion: "换算"
        case .currency: "汇率"
        }
    }

    var symbol: String {
        switch self {
        case .calculation: "function"
        case .conversion: "arrow.left.arrow.right"
        case .currency: "chart.line.uptrend.xyaxis"
        }
    }
}

struct HistoryRecord: Codable, Identifiable, Hashable {
    let id: UUID
    let kind: HistoryKind
    let title: String
    let detail: String
    let createdAt: Date

    init(kind: HistoryKind, title: String, detail: String, createdAt: Date = .now) {
        self.id = UUID()
        self.kind = kind
        self.title = title
        self.detail = detail
        self.createdAt = createdAt
    }
}

@MainActor
final class HistoryStore: ObservableObject {
    @Published private(set) var records: [HistoryRecord]
    private let storageKey = "history.records.v1"
    private let persistenceQueue = DispatchQueue(label: "com.example.LocalCalc.history-persistence", qos: .utility)

    init() {
        if let data = UserDefaults.standard.data(forKey: "history.records.v1"),
           let saved = try? JSONDecoder().decode([HistoryRecord].self, from: data) {
            records = saved
        } else {
            records = []
        }

        if !UserDefaults.standard.bool(forKey: "history.legacyMigrationComplete") {
            let legacy = (UserDefaults.standard.string(forKey: "calc.history") ?? "")
                .split(separator: "\n")
            for line in legacy {
                let parts = line.components(separatedBy: " = ")
                guard parts.count >= 2 else { continue }
                records.append(HistoryRecord(kind: .calculation, title: parts.dropLast().joined(separator: " = "), detail: parts.last ?? ""))
            }
            records = Array(records.prefix(500))
            UserDefaults.standard.set(true, forKey: "history.legacyMigrationComplete")
            persist()
        }
    }

    func add(kind: HistoryKind, title: String, detail: String) {
        guard !title.isEmpty, !detail.isEmpty else { return }
        records.insert(HistoryRecord(kind: kind, title: title, detail: detail), at: 0)
        records = Array(records.prefix(500))
        persist()
    }

    func delete(id: UUID) {
        records.removeAll { $0.id == id }
        persist()
    }

    func clear() {
        records.removeAll()
        persist()
    }

    private func persist() {
        let snapshot = records
        let storageKey = self.storageKey
        persistenceQueue.async {
            guard let data = try? JSONEncoder().encode(snapshot) else { return }
            UserDefaults.standard.set(data, forKey: storageKey)
        }
    }
}
