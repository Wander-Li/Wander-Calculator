import SwiftUI
import AVFoundation

struct CalculatorView: View {
    @ObservedObject var historyStore: HistoryStore
    @State private var expression = ""
    @State private var display = "0"
    @State private var angleMode = "DEG"
    @State private var scientific = false
    @State private var secondMode = false
    @State private var memoryValue = 0.0
    @AppStorage("haptics.enabled") private var hapticsEnabled = true
    @Environment(\.verticalSizeClass) private var verticalSizeClass
    private let basicRows = [["AC", "±", "%", "÷"], ["7", "8", "9", "×"], ["4", "5", "6", "−"], ["1", "2", "3", "+"], ["⌫", "0", ".", "="]]
    private var scientificRows: [[String]] {
        [
            ["(", ")", "mc", "m+", "m−", "mr"],
            ["2nd", "x²", "x³", "xʸ", "eˣ", "10ˣ"],
            ["1/x", "²√x", "³√x", "ʸ√x", "ln", "log₁₀"],
            ["x!", secondMode ? "sin⁻¹" : "sin", secondMode ? "cos⁻¹" : "cos", secondMode ? "tan⁻¹" : "tan", "e", "EE"],
            ["Rand", secondMode ? "sinh⁻¹" : "sinh", secondMode ? "cosh⁻¹" : "cosh", secondMode ? "tanh⁻¹" : "tanh", "π", angleMode == "DEG" ? "Rad" : "Deg"]
        ]
    }

    var body: some View { modernBody }

    private var modernBody: some View {
        GeometryReader { geometry in
            let compact = geometry.size.height < 760 || verticalSizeClass == .compact
            let scienceKeyHeight: CGFloat = compact ? 34 : 42
            #if LEGACY_APP
            let basicKeyHeight: CGFloat = compact ? 64 : 72
            let basicKeySpacing: CGFloat = compact ? 8 : 12
            #else
            let basicKeyHeight: CGFloat = compact ? 56 : 68
            let basicKeySpacing: CGFloat = compact ? 8 : 12
            #endif
            if scientific {
                ScrollView {
                    VStack(spacing: compact ? 8 : 10) {
                        header
                        display(compact: compact)
                        keyRows(scientificRows, height: scienceKeyHeight, spacing: compact ? 7 : 10)
                        keyRows(basicRows, height: compact ? 47 : 54, spacing: compact ? 7 : 10)
                    }
                    .padding(.horizontal, 20).padding(.top, 8).padding(.bottom, 16)
                    .frame(maxWidth: 520).frame(maxWidth: .infinity)
                }
                .appScrollIndicatorsHidden()
            } else {
                VStack(spacing: compact ? 8 : 12) {
                    header
                    display(compact: compact)
                    Spacer(minLength: 4)
                    keyRows(basicRows, height: basicKeyHeight, spacing: basicKeySpacing, emphasized: true)
                }
                .padding(.horizontal, 20).padding(.top, 8).padding(.bottom, 28)
                .frame(maxWidth: 520).frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
            }
        }
        .sensoryFeedback(.selection, trigger: scientific) { _, _ in hapticsEnabled && HapticSupport.available }
        .sheet(isPresented: Binding(get: { expression == "__history__" }, set: { if !$0 { expression = "" } })) {
            HistorySheet(items: calculationHistory) { item in emit(.selection); expression = item.components(separatedBy: " = ").first ?? ""; display = "0" }
                .appSheetPresentation()
        }
    }

    private var header: some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                Text("CALCULATOR").font(.system(size: 11, weight: .bold, design: .rounded)).tracking(2.2).foregroundStyle(.cyan)
                Text("计算器").font(.system(size: 26, weight: .bold, design: .rounded))
            }
            Spacer()
            HapticsSettingsButton()
            Button { scientific.toggle() } label: {
                Label(scientific ? "科学" : "标准", systemImage: "function").font(.system(size: 13, weight: .semibold))
                    .padding(.horizontal, 13).padding(.vertical, 10)
            }.appGlassButtonStyle().tint(.cyan)
        }
    }

    private var calculationHistory: [String] {
        historyStore.records.filter { $0.kind == .calculation }.map { "\($0.title) = \($0.detail)" }
    }

    private func display(compact: Bool) -> some View {
        VStack(alignment: .trailing, spacing: 8) {
            Text(expression.isEmpty ? "本地计算 · 不联网" : expression).font(.system(size: 16, design: .rounded)).foregroundStyle(.white.opacity(0.48)).lineLimit(1).minimumScaleFactor(0.65).frame(maxWidth: .infinity, alignment: .trailing)
            Text(display).font(.system(size: compact ? 48 : 54, weight: .light, design: .rounded)).monospacedDigit().lineLimit(1).minimumScaleFactor(0.35).frame(maxWidth: .infinity, alignment: .trailing)
        }.padding(.horizontal, 5).padding(.bottom, 4)
    }

    private func keyRows(_ rows: [[String]], height: CGFloat, spacing: CGFloat, emphasized: Bool = false) -> some View {
        VStack(spacing: spacing) {
            ForEach(rows, id: \.self) { row in
                HStack(spacing: spacing) {
                    ForEach(Array(row.enumerated()), id: \.offset) { _, key in
                        keyButton(key, height: height, emphasized: emphasized)
                    }
                }
            }
        }
    }

    private func keyButton(_ key: String, height: CGFloat, emphasized: Bool) -> some View {
        let op = ["÷", "×", "−", "+", "="].contains(key)
        let arithmeticOperator = ["÷", "×", "−", "+"].contains(key)
        let utility = ["AC", "±", "%", "⌫", "DEG", "HIST"].contains(key)
        #if LEGACY_APP
        let keyColor = op ? Color.white : (utility ? Color.cyan : Color.white)
        #else
        let keyColor = arithmeticOperator ? Color.orange : (key == "=" ? Color.black : (utility ? Color.cyan : Color.white))
        #endif
        #if LEGACY_APP
        #if LEGACY_APP
        let label = Text(key).font(.system(size: emphasized ? 27 : (height < 50 ? 15 : 22), weight: .medium, design: .rounded))
        #else
        let label = Text(key).font(.system(size: height < 50 ? 15 : 22, weight: .medium, design: .rounded))
        #endif
        #else
        let label = Text(key).font(.system(size: height < 50 ? 15 : 22, weight: .medium, design: .rounded))
        #endif
        let styledLabel = label.foregroundStyle(keyColor)
            .frame(maxWidth: .infinity).frame(height: height)
        return Group {
            #if LEGACY_APP
            if key.isEmpty {
                Color.clear.frame(maxWidth: .infinity).frame(height: height)
            } else {
                Button { tap(key) } label: {
                    styledLabel
                        .background {
                            if op {
                                if emphasized {
                                    Circle().fill(Color.orange)
                                } else {
                                    RoundedRectangle(cornerRadius: height * 0.24).fill(Color.orange)
                                }
                            } else if emphasized {
                                ZStack {
                                    Circle().fill(.ultraThinMaterial)
                                    Circle().fill(Color.black.opacity(0.58))
                                    Circle().fill(Color.white.opacity(0.07))
                                }
                            } else {
                                RoundedRectangle(cornerRadius: height * 0.24).fill(Color.white.opacity(0.13))
                            }
                        }
                        .overlay {
                            if !emphasized {
                                RoundedRectangle(cornerRadius: height * 0.24)
                                    .stroke(Color.white.opacity(0.18), lineWidth: 1)
                            }
                        }
                }
                .buttonStyle(.plain)
            }
            #else
            if key == "=" {
                Button { tap(key) } label: { styledLabel }
                    .appGlassButtonStyle(prominent: true).tint(.cyan)
            } else {
                Button { tap(key) } label: { styledLabel }
                    .appGlassButtonStyle().tint(op ? .cyan : (utility ? .white.opacity(0.14) : .white.opacity(0.08)))
            }
            #endif
        }
    }

    private func tap(_ key: String) {
        KeyClickPlayer.shared.play()
        switch key {
        case "AC": emit(.impact(weight: .medium, intensity: 0.4)); expression = ""; display = "0"
        case "⌫": emit(.impact(weight: .light, intensity: 0.22)); if !expression.isEmpty { expression.removeLast(); display = expression.isEmpty ? "0" : expression }
        case "HIST": emit(.selection); expression = "__history__"
        case "DEG", "Rad", "Deg": emit(.selection); angleMode = angleMode == "DEG" ? "RAD" : "DEG"
        case "2nd": emit(.selection); secondMode.toggle()
        case "mc": emit(.selection); memoryValue = 0
        case "m+": emit(.impact(weight: .medium, intensity: 0.4)); memoryValue += currentValue() ?? 0
        case "m−": emit(.impact(weight: .medium, intensity: 0.4)); memoryValue -= currentValue() ?? 0
        case "mr": emit(.selection); expression += Self.format(memoryValue); display = expression
        case "±": emit(.impact(weight: .light, intensity: 0.28)); expression = expression.hasPrefix("−") ? String(expression.dropFirst()) : "−" + (expression.isEmpty ? display : expression); display = expression
        case "=":
            do {
                let evaluationExpression = expression.contains("root(") && !expression.hasSuffix(")") ? expression + ")" : expression
                let result = try ExpressionEvaluator.evaluate(evaluationExpression, degrees: angleMode == "DEG")
                let output = Self.format(result)
                if !expression.isEmpty { historyStore.add(kind: .calculation, title: expression, detail: output) }
                emit(.success); display = output; expression = ""
            } catch { emit(.error); display = "错误"; expression = "" }
        case "%": emit(.impact(weight: .light, intensity: 0.25)); expression += "%"; display = expression
        case "sin", "cos", "tan", "ln", "log", "log₁₀", "sinh", "cosh", "tanh": emit(.impact(weight: .light, intensity: 0.25)); expression += (key == "log₁₀" ? "log10" : key) + "("
        case "sin⁻¹", "cos⁻¹", "tan⁻¹", "sinh⁻¹", "cosh⁻¹", "tanh⁻¹": emit(.impact(weight: .light, intensity: 0.25)); expression += ["sin⁻¹": "asin", "cos⁻¹": "acos", "tan⁻¹": "atan", "sinh⁻¹": "asinh", "cosh⁻¹": "acosh", "tanh⁻¹": "atanh"][key]! + "("
        case "√": emit(.impact(weight: .light, intensity: 0.25)); expression += "sqrt("
        case "x²": emit(.impact(weight: .light, intensity: 0.25)); expression += "^2"
        case "x³": emit(.impact(weight: .light, intensity: 0.25)); expression += "^3"
        case "xʸ": emit(.impact(weight: .light, intensity: 0.25)); expression += "^"
        case "π": emit(.impact(weight: .light, intensity: 0.25)); expression += "pi"
        case "e": emit(.impact(weight: .light, intensity: 0.25)); expression += "e"
        case "x!", "!": emit(.impact(weight: .light, intensity: 0.25)); expression += "!"
        case "1/x": applyTransform { 1 / $0 }
        case "²√x": applyTransform { $0 >= 0 ? Foundation.sqrt($0) : .nan }
        case "³√x": applyTransform { $0 < 0 ? -Foundation.pow(-$0, 1.0 / 3.0) : Foundation.pow($0, 1.0 / 3.0) }
        case "ʸ√x":
            emit(.impact(weight: .light, intensity: 0.25))
            expression = "root(" + (currentValue().map(Self.format) ?? display) + ","
            display = expression
        case "eˣ": applyTransform { Foundation.exp($0) }
        case "10ˣ": applyTransform { Foundation.pow(10, $0) }
        case "EE": emit(.impact(weight: .light, intensity: 0.25)); expression += "e"; display = expression
        case "Rand": emit(.selection); expression += Self.format(Double.random(in: 0..<1)); display = expression
        default: emit(.impact(weight: .light, intensity: 0.22)); expression += key; display = expression
        }
    }

    private func currentValue() -> Double? {
        let source = expression.isEmpty ? display : expression
        return try? ExpressionEvaluator.evaluate(source, degrees: angleMode == "DEG")
    }

    private func applyTransform(_ transform: (Double) -> Double) {
        emit(.impact(weight: .light, intensity: 0.25))
        guard let value = currentValue() else { display = "错误"; return }
        let result = transform(value)
        guard result.isFinite else { display = "错误"; return }
        display = Self.format(result)
        expression = display
    }
    private func emit(_ feedback: SensoryFeedback) {
        if hapticsEnabled { LegacyHaptics.play(feedback) }
    }
    static func format(_ value: Double) -> String {
        guard value.isFinite else { return "错误" }
        if abs(value) < 1e12 && abs(value) > 1e-7 { return String(format: "%.10g", value) }
        return String(format: "%.6e", value)
    }
}

private struct HistorySheet: View {
    let items: [String]
    let select: (String) -> Void
    var body: some View {
        AppNavigationContainer {
            List(items, id: \.self) { item in Button(item) { select(item) }.foregroundStyle(.primary) }
                .overlay { if items.isEmpty { AppEmptyState(title: "暂无记录", symbol: "clock.arrow.circlepath") } }
                .navigationTitle("计算历史").navigationBarTitleDisplayMode(.inline)
        }.preferredColorScheme(.dark)
    }
}


private final class KeyClickPlayer {
    static let shared = KeyClickPlayer()
    private var player: AVAudioPlayer?

    private init() {
        guard let url = Bundle.main.url(forResource: "KeyClick", withExtension: "wav"),
              let audioPlayer = try? AVAudioPlayer(contentsOf: url) else { return }
        player = audioPlayer
        player?.volume = 0.42
        player?.prepareToPlay()
    }

    func play() {
        player?.currentTime = 0
        player?.play()
    }
}
