# 本地计算器（iOS 15–18）

此文件夹是独立的旧系统 Xcode 工程。打开 `LocalCalc-iOS15-18.xcodeproj` 后即可在 Xcode 中调试；工程默认最低版本为 iOS 15，并启用了旧系统兼容界面。

- 市场版本：1.0.1
- Bundle ID：`com.example.LocalCalc.legacy`（分发前可替换为团队自己的标识符）
- Scheme / Target：`LocalCalc`
